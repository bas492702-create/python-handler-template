"""
webhook_bot.py — نسخة البوت المهيّأة للعمل كـ Webhook (متوافقة مع Serverless)

هذا الملف يعمل بطريقتين:
  1) تشغيل محلي:  python webhook_bot.py            → يرفع سيرفر Flask على المنفذ PORT ويضبط الويبهوك (إن وُجد PUBLIC_URL)
  2) Python Cloud Function على EdgeOne Pages        → استيراد الدالة handler عبر cloud-functions/api/telegram-webhook.py

المتغيّرات المطلوبة:
  BOT_TOKEN        : توكن البوت من @BotFather
  WEBHOOK_SECRET   : نص عشوائي طويل (يُرسل في ترويسة X-Telegram-Bot-Api-Secret-Token)
  WEBHOOK_PATH     : مسار الويبهوك، افتراضيًا /api/telegram-webhook
  PUBLIC_URL       : رابط النشر العام (لضبط الويبهوك تلقائيًا)
"""

import html
import json
import logging
import os
import time
import urllib.parse
import urllib.request
from datetime import datetime, timezone

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("webhook-bot")

BOT_TOKEN = os.environ.get("BOT_TOKEN", "")
WEBHOOK_SECRET = os.environ.get("WEBHOOK_SECRET", "")
WEBHOOK_PATH = os.environ.get("WEBHOOK_PATH", "/api/telegram-webhook")
PUBLIC_URL = os.environ.get("PUBLIC_URL", "").rstrip("/")
API = "https://api.telegram.org/bot" + BOT_TOKEN

# ذاكرة مؤقتة للحد من الردود المكررة (تُصفّر مع كل بدء بارد للدالة)
SEEN_UPDATES = set()
MAX_SEEN = 500


def api_call(method, payload=None, timeout=10):
    """استدعاء Telegram Bot API بدون مكتبات خارجية."""
    if not BOT_TOKEN:
        raise RuntimeError("BOT_TOKEN غير مضبوط")
    data = None
    headers = {}
    if payload is not None:
        data = json.dumps(payload).encode("utf-8")
        headers["Content-Type"] = "application/json"
    req = urllib.request.Request(API + "/" + method, data=data, headers=headers, method="POST" if data else "GET")
    with urllib.request.urlopen(req, timeout=timeout) as res:
        return json.loads(res.read().decode("utf-8"))


def send_message(chat_id, text, reply_to=None):
    payload = {
        "chat_id": chat_id,
        "text": text[:4096],
        "parse_mode": "HTML",
        "disable_web_page_preview": True,
    }
    if reply_to:
        payload["reply_to_message_id"] = reply_to
        payload["allow_sending_without_reply"] = True
    try:
        return api_call("sendMessage", payload)
    except Exception as exc:  # noqa: BLE001
        log.error("sendMessage failed: %s", exc)
        # إعادة المحاولة بدون HTML إن كانت الرسالة تحتوي رموزًا غير مدعومة
        payload.pop("parse_mode", None)
        payload["text"] = text[:4096]
        try:
            return api_call("sendMessage", payload)
        except Exception as exc2:  # noqa: BLE001
            log.error("sendMessage retry failed: %s", exc2)
            return {"ok": False, "description": str(exc2)}


HELP_TEXT = (
    "<b>الأوامر المتاحة</b>\n"
    "/start — رسالة الترحيب\n"
    "/help — هذه القائمة\n"
    "/time — الوقت الحالي (UTC)\n"
    "/id — معرّف محادثتك\n"
    "أي نص آخر — سأعيده لك (echo)"
)


def build_reply(update):
    """يُرجع (chat_id, message_id, نص الرد) أو None."""
    msg = update.get("message") or update.get("edited_message")
    if not msg:
        return None
    chat = msg.get("chat") or {}
    chat_id = chat.get("id")
    if chat_id is None:
        return None
    message_id = msg.get("message_id")
    text = (msg.get("text") or "").strip()
    user = msg.get("from") or {}
    name = user.get("first_name") or "صديقي"

    cmd = ""
    if text.startswith("/"):
        cmd = text[1:].split()[0].split("@")[0].lower()

    if cmd == "start":
        return chat_id, message_id, "أهلًا بك يا <b>%s</b>! 👋\nأنا بوت يعمل عبر <b>Webhook</b> على EdgeOne.\n%s" % (
            html.escape(name), HELP_TEXT)
    if cmd == "help":
        return chat_id, message_id, HELP_TEXT
    if cmd == "time":
        now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
        return chat_id, message_id, "🕒 الوقت الآن: <code>%s</code>" % now
    if cmd == "id":
        return chat_id, message_id, "🆔 معرّف المحادثة: <code>%s</code>" % chat_id
    if cmd:
        return chat_id, message_id, "أمر غير معروف 🤔\n%s" % HELP_TEXT
    if text:
        return chat_id, message_id, "وصلتني رسالتك ✅\n<blockquote>%s</blockquote>" % html.escape(text[:3000])
    return chat_id, message_id, "أرسل /help لعرض الأوامر."


def process_update(update):
    """يعالج تحديثًا واحدًا من تلغرام."""
    if not isinstance(update, dict):
        return False
    uid = update.get("update_id")
    if uid is not None:
        if uid in SEEN_UPDATES:
            return True
        SEEN_UPDATES.add(uid)
        if len(SEEN_UPDATES) > MAX_SEEN:
            SEEN_UPDATES.clear()
    out = build_reply(update)
    if not out:
        return True
    chat_id, message_id, text = out
    send_message(chat_id, text, message_id)
    return True


# ============================ وضع السيرفر المحلي ============================
def ensure_webhook():
    """يضبط الويبهوك على تلغرام عند توفر PUBLIC_URL."""
    if not (BOT_TOKEN and PUBLIC_URL):
        log.warning("تخطّي setWebhook: حدد BOT_TOKEN و PUBLIC_URL")
        return None
    url = PUBLIC_URL + WEBHOOK_PATH
    payload = {
        "url": url,
        "max_connections": 40,
        "allowed_updates": ["message", "edited_message", "callback_query"],
        "drop_pending_updates": True,
    }
    if WEBHOOK_SECRET:
        payload["secret_token"] = WEBHOOK_SECRET
    try:
        res = api_call("setWebhook", payload)
        log.info("setWebhook → %s (%s)", url, res.get("description"))
        return res
    except Exception as exc:  # noqa: BLE001
        log.error("setWebhook failed: %s", exc)
        return None


def run_local_server():
    """سيرفر Flask للتطوير المحلي وللتجربة على أي منصة تدعم Python."""
    try:
        from flask import Flask, request, jsonify
    except ImportError:
        raise SystemExit("ثبّت Flask أولًا:  pip install flask")

    app = Flask(__name__)

    @app.get("/")
    def index():
        info = {}
        try:
            info = api_call("getMe").get("result", {})
        except Exception:  # noqa: BLE001
            info = {"error": "BOT_TOKEN غير صالح أو غير مضبوط"}
        return jsonify({
            "service": "webhook-bot",
            "status": "ok",
            "webhook_path": WEBHOOK_PATH,
            "bot": info,
            "time": int(time.time()),
        })

    @app.post(WEBHOOK_PATH)
    def webhook():
        if WEBHOOK_SECRET:
            got = request.headers.get("X-Telegram-Bot-Api-Secret-Token", "")
            if got != WEBHOOK_SECRET:
                return jsonify({"ok": False, "error": "bad secret"}), 401
        update = request.get_json(silent=True) or {}
        if not isinstance(update, dict):
            return jsonify({"ok": False, "error": "update must be a JSON object"}), 400
        try:
            process_update(update)
        except Exception as exc:  # noqa: BLE001
            log.exception("process_update failed: %s", exc)
        # نردّ 200 دائمًا حتى لا يعيد تلغرام إرسال التحديث
        return jsonify({"ok": True})

    @app.get(WEBHOOK_PATH)
    def webhook_info():
        return jsonify({"ok": True, "hint": "هذا مسار Webhook — تلغرام يرسل إليه POST فقط."})

    port = int(os.environ.get("PORT", "8080"))
    ensure_webhook()
    log.info("listening on 0.0.0.0:%s%s", port, WEBHOOK_PATH)
    app.run(host="0.0.0.0", port=port)


if __name__ == "__main__":
    run_local_server()

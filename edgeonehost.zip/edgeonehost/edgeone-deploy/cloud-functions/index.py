"""
cloud-functions/index.py — مسار الصحة الرئيسي (GET /)
يستخدمه EdgeOne للتأكد من أن مشروع الدوال يعمل.
"""

import json
import os
import time
from http.server import BaseHTTPRequestHandler


class handler(BaseHTTPRequestHandler):
    def do_GET(self):
        body = json.dumps({
            "service": "edgeonehost-functions",
            "ok": True,
            "routes": {
                "/": "health",
                "/api/telegram-webhook": "Telegram bot webhook (POST)",
            },
            "bot_token_set": bool(os.environ.get("BOT_TOKEN")),
            "webhook_secret_set": bool(os.environ.get("WEBHOOK_SECRET")),
            "time": int(time.time()),
        }, ensure_ascii=False).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, fmt, *args):  # noqa: A003
        return

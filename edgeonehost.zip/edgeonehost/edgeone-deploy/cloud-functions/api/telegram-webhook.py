"""
cloud-functions/api/telegram-webhook.py
=======================================
Python Cloud Function على EdgeOne Pages (Handler mode) لاستقبال تحديثات تلغرام
عبر Webhook. ملف مستقل بالكامل (Standard Library فقط) حتى لا يحتاج أي تبعيات.

المسار النهائي على النطاق:
    https://<your-project>.edgeone.app/api/telegram-webhook

متغيّرات البيئة (تُضاف من لوحة EdgeOne → Settings → Environment Variables):
    BOT_TOKEN       : توكن البوت من @BotFather        (إلزامي)
    WEBHOOK_SECRET  : نص عشوائي طويل                  (موصى به بشدة)

بعد النشر، اضبط الويبهوك مرة واحدة (من جهازك أو من أي مكان):

    curl -X POST "https://api.telegram.org/bot<TOKEN>/setWebhook" \
         -H "Content-Type: application/json" \
         -d '{"url":"https://<project>.edgeone.app/api/telegram-webhook",
              "secret_token":"<WEBHOOK_SECRET>",
              "allowed_updates":["message","edited_message"],
              "drop_pending_updates":true}'

للتحقق:  curl "https://api.telegram.org/bot<TOKEN>/getWebhookInfo"
"""

import html
import json
import os
import time
import urllib.request
from http.server import BaseHTTPRequestHandler

BOT_TOKEN = os.environ.get("BOT_TOKEN", "")
WEBHOOK_SECRET = os.environ.get("WEBHOOK_SECRET", "")
API = "https://api.telegram.org/bot" + BOT_TOKEN
TIMEOUT = 8  # يجب أن يبقى أقل من مهلة تنفيذ الدالة على المنصة

HELP_TEXT = (
    "<b>الأوامر المتاحة</b>\n"
    "/start — رسالة الترحيب\n"
    "/help — هذه القائمة\n"
    "/time — الوقت الحالي (UTC)\n"
    "/id — معرّف محادثتك\n"
    "أي نص آخر — سأعيده لك (echo)"
)


def api_call(method, payload=None):
    """استدعاء Bot API بـ urllib (بدون requests)."""
    if not BOT_TOKEN:
        raise RuntimeError("BOT_TOKEN is not set")
    data = None
    headers = {}
    if payload is not None:
        data = json.dumps(payload).encode("utf-8")
        headers["Content-Type"] = "application/json"
    req = urllib.request.Request(
        API + "/" + method, data=data, headers=headers,
        method="POST" if data else "GET",
    )
    with urllib.request.urlopen(req, timeout=TIMEOUT) as res:
        return json.loads(res.read().decode("utf-8"))


def send(chat_id, text, reply_to=None):
    payload = {
        "chat_id": chat_id,
        "text": text[:4096],
        "parse_mode": "HTML",
        "disable_web_page_preview": True,
    }
    if reply_to:
        payload["reply_to_message_id"] = reply_to
        payload["allow_sending_without_reply"] = True
    try:
        api_call("sendMessage", payload)
        return True
    except Exception:  # noqa: BLE001
        payload.pop("parse_mode", None)
        try:
            api_call("sendMessage", payload)
            return True
        except Exception:  # noqa: BLE001
            return False


def reply_for(update):
    """تحديد نص الرد المناسب لتحديث تلغرام."""
    msg = update.get("message") or update.get("edited_message") or {}
    chat = msg.get("chat") or {}
    chat_id = chat.get("id")
    if chat_id is None:
        return None
    text = (msg.get("text") or "").strip()
    name = html.escape(((msg.get("from") or {}).get("first_name") or "صديقي")[:64])
    cmd = text[1:].split()[0].split("@")[0].lower() if text.startswith("/") else ""

    if cmd == "start":
        body = "أهلًا بك يا <b>%s</b>! 👋\nأنا بوت يعمل عبر <b>Webhook</b> على EdgeOne.\n%s" % (name, HELP_TEXT)
    elif cmd == "help":
        body = HELP_TEXT
    elif cmd == "time":
        body = "🕒 الوقت الآن: <code>%s</code>" % time.strftime("%Y-%m-%d %H:%M:%S UTC", time.gmtime())
    elif cmd == "id":
        body = "🆔 معرّف المحادثة: <code>%s</code>" % chat_id
    elif cmd:
        body = "أمر غير معروف 🤔\n%s" % HELP_TEXT
    elif text:
        body = "وصلتني رسالتك ✅\n<blockquote>%s</blockquote>" % html.escape(text[:3000])
    else:
        body = "أرسل /help لعرض الأوامر."
    return chat_id, msg.get("message_id"), body


class handler(BaseHTTPRequestHandler):
    """نقطة الدخول التي تتعرف عليها EdgeOne Pages."""

    # ---------- أدوات الاستجابة ----------
    def _json(self, code, obj):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _body(self):
        try:
            length = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            length = 0
        if length <= 0 or length > 1_000_000:
            return b""
        return self.rfile.read(length)

    @property
    def path_clean(self):
        return (self.path or "/").split("?")[0].rstrip("/") or "/"

    # ---------- GET: فحص الحالة ----------
    def do_GET(self):
        info = {}
        try:
            info = api_call("getMe").get("result", {})
        except Exception as exc:  # noqa: BLE001
            info = {"error": str(exc), "hint": "تحقق من BOT_TOKEN في متغيرات البيئة"}
        hook = {}
        try:
            hook = api_call("getWebhookInfo").get("result", {})
        except Exception:  # noqa: BLE001
            hook = {}
        self._json(200, {
            "service": "edgeone-telegram-webhook",
            "ok": True,
            "path": self.path_clean,
            "bot": info,
            "webhook": {
                "url": hook.get("url"),
                "pending_update_count": hook.get("pending_update_count"),
                "last_error_message": hook.get("last_error_message"),
            },
            "time": int(time.time()),
        })

    # ---------- POST: استقبال التحديث ----------
    def do_POST(self):
        # 1) التحقق من السر
        if WEBHOOK_SECRET:
            got = self.headers.get("X-Telegram-Bot-Api-Secret-Token", "")
            if got != WEBHOOK_SECRET:
                self._json(401, {"ok": False, "error": "invalid secret token"})
                return

        # 2) قراءة التحديث
        raw = self._body()
        try:
            update = json.loads(raw.decode("utf-8")) if raw else {}
        except Exception:  # noqa: BLE001
            self._json(400, {"ok": False, "error": "invalid json"})
            return
        if not isinstance(update, dict):
            self._json(400, {"ok": False, "error": "update must be a JSON object"})
            return

        # 3) نردّ 200 أولًا؟ لا: نعالج ثم نردّ، لكن نضمن عدم رمي استثناء
        try:
            out = reply_for(update)
            if out:
                chat_id, message_id, text = out
                send(chat_id, text, message_id)
        except Exception as exc:  # noqa: BLE001
            self._json(200, {"ok": True, "handled": False, "note": str(exc)[:200]})
            return

        self._json(200, {"ok": True})

    # إسكات سجلات http.server الافتراضية
    def log_message(self, fmt, *args):  # noqa: A003
        return

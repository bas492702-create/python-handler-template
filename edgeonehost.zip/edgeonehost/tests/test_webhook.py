"""اختبار منطق الويبهوك محليًا بدون توكن حقيقي (اختبار استجابة/أمان فقط)."""
import json, os, sys, threading, time, urllib.request, urllib.error
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "edgeone-deploy"))

os.environ["BOT_TOKEN"] = ""           # لا توكن: اختبار مسارات الرد
os.environ["WEBHOOK_SECRET"] = "test-secret-123"
os.environ["PORT"] = "8098"

import webhook_bot as wb

# 1) منطق بناء الردود
def upd(text, chat=555, mid=7):
    return {"update_id": 1, "message": {"message_id": mid, "chat": {"id": chat},
            "from": {"first_name": "أحمد"}, "text": text}}

out = wb.build_reply(upd("/start"))
assert out and out[0] == 555 and "أحمد" in out[2], out
print("PASS build_reply /start →", out[2].split("\n")[0])
out = wb.build_reply(upd("/id"))
assert str(555) in out[2]
print("PASS build_reply /id")
out = wb.build_reply(upd("نص عادي <b>اختبار</b>"))
assert "&lt;b&gt;" in out[2], out[2]
print("PASS escaping HTML في الـ echo")
out = wb.build_reply({"update_id": 2})
assert out is None
print("PASS تجاهل التحديثات بلا رسالة")

# منع التكرار
wb.send_message = lambda *a, **k: {"ok": True}   # تعطيل الإرسال الحقيقي
assert wb.process_update(upd("/help")) is True
assert wb.process_update(upd("/help")) is True   # نفس update_id → لا إرسال مكرر
print("PASS منع التكرار بنفس update_id")

# 2) خادم Flask فعلي
from flask import Flask
app = wb.App if hasattr(wb, "App") else None
threading.Thread(target=wb.run_local_server, daemon=True).start()
time.sleep(1.6)

def req(path, method="GET", body=None, headers=None):
    r = urllib.request.Request("http://127.0.0.1:8098" + path, method=method,
                               data=json.dumps(body).encode() if body else None,
                               headers=headers or {})
    try:
        with urllib.request.urlopen(r, timeout=5) as res:
            return res.status, json.loads(res.read().decode())
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read().decode())

st, data = req("/")
assert st == 200 and data["service"] == "webhook-bot", data
print("PASS GET / →", st, data["status"], "| bot:", str(data["bot"])[:60])

st, data = req("/api/telegram-webhook")
assert st == 200
print("PASS GET webhook path →", st, data.get("hint"))

st, data = req("/api/telegram-webhook", "POST", upd("/start"))
assert st == 401, (st, data)
print("PASS رفض POST بلا secret → 401")

st, data = req("/api/telegram-webhook", "POST", upd("/start"),
               {"Content-Type": "application/json",
                "X-Telegram-Bot-Api-Secret-Token": "test-secret-123"})
assert st == 200 and data.get("ok") is True, (st, data)
print("PASS قبول POST مع secret صحيح → 200 OK")
print("\nALL WEBHOOK TESTS PASSED")

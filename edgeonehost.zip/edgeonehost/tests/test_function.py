"""اختبار دالة EdgeOne Python (Handler mode) محليًا."""
import importlib.util, json, os, sys, threading, time, urllib.request, urllib.error
from http.server import HTTPServer

os.environ["BOT_TOKEN"] = ""
os.environ["WEBHOOK_SECRET"] = "s3cret"

path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "edgeone-deploy", "cloud-functions", "api", "telegram-webhook.py")
spec = importlib.util.spec_from_file_location("tgwh", path)
mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)

srv = HTTPServer(("127.0.0.1", 8097), mod.handler)
threading.Thread(target=srv.serve_forever, daemon=True).start()
time.sleep(0.4)

def req(method="GET", body=None, headers=None):
    r = urllib.request.Request("http://127.0.0.1:8097/api/telegram-webhook", method=method,
        data=json.dumps(body).encode() if body else None, headers=headers or {})
    try:
        with urllib.request.urlopen(r, timeout=8) as res:
            return res.status, json.loads(res.read().decode())
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read().decode())

st, d = req()
assert st == 200 and d["service"] == "edgeone-telegram-webhook", d
print("PASS GET health →", st, "| webhook url:", d["webhook"]["url"], "| bot:", str(d["bot"])[:70])

st, d = req("POST", {"update_id": 1, "message": {"message_id": 3, "chat": {"id": 42},
             "from": {"first_name": "Sara"}, "text": "/help"}})
assert st == 401, (st, d)
print("PASS POST بلا secret → 401 invalid secret token")

st, d = req("POST", {"update_id": 1, "message": {"message_id": 3, "chat": {"id": 42},
             "from": {"first_name": "Sara"}, "text": "/help"}},
            {"Content-Type": "application/json", "X-Telegram-Bot-Api-Secret-Token": "s3cret"})
assert st == 200 and d.get("ok") is True, (st, d)
print("PASS POST مع secret صحيح → 200 OK (الإرسال فشل لأن التوكن فارغ، لكن الدالة ردّت 200)")

st, d = req("POST", "not-json", {"Content-Type": "application/json", "X-Telegram-Bot-Api-Secret-Token": "s3cret"})
print("PASS body غير صالح →", st, d)
print("\nCLOUD FUNCTION OK")

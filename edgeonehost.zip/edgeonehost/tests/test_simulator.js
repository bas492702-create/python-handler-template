/**
 * اختبار محرك محاكاة البوت (simulator.js) بدون متصفح — Node.js
 * التشغيل:  node tests/test_simulator.js
 */
const fs = require("fs");
const path = require("path");
const vm = require("vm");

const file = path.join(__dirname, "..", "assets", "js", "simulator.js");
const sandbox = { window: {} };
vm.createContext(sandbox);
vm.runInContext(fs.readFileSync(file, "utf8"), sandbox, { filename: "simulator.js" });
const BotSim = sandbox.window.BotSim;

let pass = 0, fail = 0;
function check(name, got, expected) {
  const ok = typeof expected === "function" ? expected(got) : got === expected;
  if (ok) { pass++; console.log("PASS " + name + (typeof expected === "string" ? " → " + got.slice(0, 90) : "")); }
  else { fail++; console.log("FAIL " + name + "\n   got: " + String(got).slice(0, 200) + "\n   exp: " + String(expected).slice(0, 200)); }
}

const echo = `import telebot
BOT_TOKEN = os.environ.get("BOT_TOKEN", "")
bot = telebot.TeleBot(BOT_TOKEN)

@bot.message_handler(commands=["start"])
def send_welcome(message):
    name = message.from_user.first_name or "صديقي"
    bot.reply_to(message, "أهلًا بك يا " + name + "! أنا بوت تجريبي.")

@bot.message_handler(commands=["time"])
def send_time(message):
    bot.reply_to(message, "الوقت الآن: " + datetime.now().strftime("%Y-%m-%d"))

@bot.message_handler(func=lambda message: True)
def echo_all(message):
    bot.reply_to(message, "وصلتني رسالتك: " + message.text)

if __name__ == "__main__":
    bot.infinity_polling()
`;

const aiogram = `from aiogram import Bot, Dispatcher, F
@dp.message(CommandStart())
async def cmd_start(message: Message):
    await message.answer(f"أهلًا {message.from_user.first_name}! اكتب /help")

@dp.message(Command("id"))
async def cmd_id(message: Message):
    await message.answer("معرّفك: " + str(message.chat.id))

@dp.message(F.text)
async def echo(message: Message):
    await message.answer("صدى: " + message.text)
`;

const ptb = `from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, filters

async def start(update, context):
    await update.message.reply_text("مرحبًا بك في بوت PTB! استخدم /help")

async def echo(update, context):
    await update.message.reply_text("قلت: " + update.message.text)

app = ApplicationBuilder().token("x").build()
app.add_handler(CommandHandler("start", start))
app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, echo))
`;

// ---- 1) الأمثلة الجاهزة ----
Object.keys(BotSim.samples).forEach(k => {
  const s = BotSim.samples[k];
  check("مثال محمّل: " + s.name, typeof s.code === "string" && s.code.length > 100, true);
  const prof = BotSim.profile(s.code);
  check("تحليل مثال " + s.name + " بلا استثناء", typeof prof.lines === "number", true);
});

// ---- 2) telebot ----
let prof = BotSim.profile(echo);
check("telebot: الإطار", prof.framework.id, "telebot");
check("telebot: الأوامر", prof.commands.join(","), "start,time");
check("telebot: /start يحيّي باسم المستخدم", BotSim.buildReply(prof, "/start", { name: "سامر" }).text, "أهلًا بك يا سامر! أنا بوت تجريبي.");
check("telebot: echo يردّد النص", BotSim.buildReply(prof, "مرحبا", {}).text, "وصلتني رسالتك: مرحبا");
check("telebot: /time ينتج وقتًا فعليًا", BotSim.buildReply(prof, "/time", {}).text, t => /الوقت الآن: \d{4}-\d{2}-\d{2}/.test(t));
check("telebot: أمر غير موجود", BotSim.buildReply(prof, "/xyz", {}).text, t => t.indexOf("لا يوجد معالج") > -1);
check("telebot: التوكن من البيئة", prof.tokenFromEnv, true);
check("telebot: تحذير polling", prof.usesPolling, true);

// ---- 3) aiogram ----
prof = BotSim.profile(aiogram);
check("aiogram: الإطار", prof.framework.id, "aiogram");
check("aiogram: /start", BotSim.buildReply(prof, "/start", { name: "ليلى" }).text, "أهلًا ليلى! اكتب /help");
check("aiogram: /id", BotSim.buildReply(prof, "/id", {}).text, t => t.indexOf("100200300") > -1);
check("aiogram: echo", BotSim.buildReply(prof, "hello", {}).text, "صدى: hello");

// ---- 4) python-telegram-bot ----
prof = BotSim.profile(ptb);
check("PTB: الإطار", prof.framework.id, "ptb");
check("PTB: /start", BotSim.buildReply(prof, "/start", {}).text, "مرحبًا بك في بوت PTB! استخدم /help");
check("PTB: echo", BotSim.buildReply(prof, "مرحبا", {}).text, "قلت: مرحبا");

// ---- 5) الملف المعطوب ----
prof = BotSim.profile(BotSim.samples.broken.code);
check("broken: يكتشف التوكن المكتوب في الكود", !!prof.tokenLiteral, true);
check("broken: يرشد إلى الأوامر المتاحة", BotSim.buildReply(prof, "مرحبا", {}).text, t => t.indexOf("/start") > -1);

// ---- 6) أدوات مساعدة ----
check("strftime: %Y-%m-%d", BotSim.strftimeJS("%Y-%m-%d", new Date(2026, 0, 5)), "2026-01-05");
check("strftime: %H:%M", BotSim.strftimeJS("%H:%M", new Date(2026, 0, 5, 9, 7)), "09:07");
check("exprToTemplate: رسالة عادية", BotSim.exprToTemplate('"نص فقط"'), "نص فقط");
check("interpolate: {name}", BotSim.interpolate("أهلًا {name}", { name: "نور", now: BotSim.nowCtx() }), "أهلًا نور");
check("كود فارغ لا يكسر المحرك", BotSim.profile("").framework.id, "none");

console.log("\n===== " + pass + "/" + (pass + fail) + " ناجح =====");
process.exit(fail ? 1 : 0);

"""اختبار آلي شامل لموقع EdgeOneHost عبر Playwright (Chromium headless)."""
import asyncio, json, os, sys
from playwright.async_api import async_playwright

BASE = os.environ.get("TEST_BASE", "http://127.0.0.1:8099/index.html")
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "docs", "screens")
os.makedirs(OUT, exist_ok=True)
results = []
def check(name, ok, extra=""):
    results.append((name, bool(ok), extra))
    print(("PASS " if ok else "FAIL ") + name + ((" | " + str(extra)) if extra else ""))

async def main():
    async with async_playwright() as p:
        browser = await p.chromium.launch()
        page = await browser.new_page(viewport={"width": 1440, "height": 960}, device_scale_factor=1)
        errors, console = [], []
        page.on("console", lambda m: console.append((m.type, m.text)))
        page.on("pageerror", lambda e: errors.append(str(e)))

        await page.goto(BASE, wait_until="networkidle")
        check("تحميل الصفحة", await page.title() != "", await page.title())
        check("لا أخطاء JS عند التحميل", not errors, errors)

        # عناصر أساسية
        for sel, name in [(".site-header", "الهيدر"), ("#app", "محطة التحكم"), ("#dropzone", "منطقة الرفع"),
                          ("#editor", "المحرر"), ("#btnRun", "زر التشغيل"), ("#simBody", "المحاكي"),
                          ("#hostcheck", "قسم الفحص"), (".faq details", "الأسئلة")]:
            check("عنصر موجود: " + name, await page.locator(sel).count() > 0)

        # الملف الافتراضي محمّل
        code = await page.input_value("#editor")
        check("مثال افتراضي محمّل في المحرر", "telebot" in code, len(code))
        check("قائمة الملفات فيها ملف", await page.locator("#fileList .file-item").count() >= 1)

        # الفحص التلقائي
        score = await page.eval_on_selector("#ringVal", "el => el.textContent")
        check("درجة الفحص ظهرت", score.strip() not in ("", "—"), score)
        nfind = await page.locator("#findings .finding").count()
        check("نتائج الفحص معروضة", nfind >= 5, nfind)

        # تبويبات
        await page.click('.tab[data-tab="check"]')
        check("تبويب الفحص يفتح", await page.locator('.panel[data-panel="check"]').is_visible())
        await page.click('.tab[data-tab="console"]')
        check("تبويب السجل يفتح", await page.locator('.panel[data-panel="console"]').is_visible())

        # تشغيل بلا توكن -> يجب أن يعطي تحذير/خطأ منطقي بدون كسر الصفحة
        await page.click("#btnRun")
        await page.wait_for_timeout(1800)
        status = await page.inner_text("#statusPill")
        logtext = await page.inner_text("#logBox")
        check("التشغيل يعطي حالة (بلا توكن)", len(status) > 3, status)
        check("السجل يحتوي على السطور التشغيلية", "getMe" in logtext or "توكن" in logtext, logtext[-260:].replace("\n", " | "))

        # تحقق من صيغة توكن خاطئة (لا شبكة)
        await page.fill("#tokenInput", "abc:def")
        await page.click("#btnVerify")
        await page.wait_for_timeout(900)
        hint = await page.inner_text("#tokenHint")
        check("رفض صيغة توكن غير صحيحة", "غير صحيحة" in hint or "يشبه" in hint, hint)

        # تحقق حقيقي من تلغرام بتوكن وهمي بصيغة صحيحة (يتطلب شبكة)
        await page.fill("#tokenInput", "123456789:AAFakeTokenForTestingCORS1234567890abc")
        await page.click("#btnVerify")
        await page.wait_for_timeout(3500)
        hint2 = await page.inner_text("#tokenHint")
        tg_ok = ("Unauthorized" in hint2) or ("مرفوض" in hint2) or ("صحيح" in hint2) or ("تعذّر" in hint2)
        check("محاولة تحقق حقيقية من تلغرام (رد متوقع)", tg_ok, hint2[:220])
        check("لا أخطاء JS بعد التحقق", not errors, errors)

        # محاكاة محادثة
        await page.fill("#simInput", "/start")
        await page.click('#simForm button')
        await page.wait_for_timeout(600)
        msgs = await page.locator("#simBody .msg.bot").all_inner_texts()
        check("المحاكي يرد على /start", len(msgs) >= 2, msgs[-1][:120] if msgs else "")
        await page.fill("#simInput", "/help")
        await page.click('#simForm button')
        await page.wait_for_timeout(600)
        msgs2 = await page.locator("#simBody .msg.bot").all_inner_texts()
        check("المحاكي يرد على /help", len(msgs2) > len(msgs), (msgs2[-1][:120] if msgs2 else ""))
        await page.fill("#simInput", "مرحبا")
        await page.click('#simForm button')
        await page.wait_for_timeout(600)
        msgs3 = await page.locator("#simBody .msg.bot").all_inner_texts()
        check("المحاكي يرد على نص عادي", len(msgs3) > len(msgs2), (msgs3[-1][:120] if msgs3 else ""))

        # تحميل الملف المعطوب والتحقق من كشف الأخطاء
        await page.click('[data-sample="broken"]')
        await page.wait_for_timeout(900)
        fails = await page.locator("#findings .finding.fail").count()
        score2 = await page.eval_on_selector("#ringVal", "el => el.textContent")
        check("كشف أخطاء الملف المعطوب", fails >= 3, "fails=%d score=%s" % (fails, score2))
        await page.click('.tab[data-tab="check"]')
        await page.screenshot(path=os.path.join(OUT, "check-broken.png"), full_page=False)

        # فحص الموقع (محلي + فحص شبكة تلغرام)
        await page.click("#btnAuditSite")
        await page.wait_for_timeout(2500)
        rows = await page.locator("#auditOut .finding").count()
        check("فحص الموقع يعرض نتائج", rows >= 6, rows)

        await page.click("#btnAuditTelegram")
        await page.wait_for_timeout(3000)
        tgtxt = await page.inner_text("#auditOut")
        check("فحص اتصال تلغرام يعمل", ("الاتصال بتلغرام" in tgtxt) or ("API" in tgtxt) or ("api.telegram" in tgtxt), tgtxt[:200].replace("\n", " | "))

        # الرجوع للمثال السليم + لقطة
        await page.click('[data-sample="simple"]')
        await page.wait_for_timeout(600)
        await page.click('.tab[data-tab="code"]')
        await page.screenshot(path=os.path.join(OUT, "desktop-app.png"), full_page=False)
        await page.goto(BASE, wait_until="networkidle")
        await page.wait_for_timeout(1200)
        await page.screenshot(path=os.path.join(OUT, "desktop-hero.png"), full_page=False)
        await page.screenshot(path=os.path.join(OUT, "desktop-full.png"), full_page=True)

        # الجوال
        mob = await browser.new_page(viewport={"width": 390, "height": 844}, device_scale_factor=2, is_mobile=True, has_touch=True)
        merr = []
        mob.on("pageerror", lambda e: merr.append(str(e)))
        await mob.goto(BASE, wait_until="networkidle")
        await mob.wait_for_timeout(1200)
        overflow = await mob.evaluate("() => document.documentElement.scrollWidth - document.documentElement.clientWidth")
        check("لا تمرير أفقي على الجوال", overflow <= 1, "overflow=%spx" % overflow)
        await mob.screenshot(path=os.path.join(OUT, "mobile-hero.png"))
        await mob.click("#burger")
        await mob.wait_for_timeout(350)
        check("قائمة الجوال تفتح", await mob.locator("#navLinks.open").count() == 1)
        await mob.screenshot(path=os.path.join(OUT, "mobile-menu.png"))
        check("لا أخطاء JS على الجوال", not merr, merr)

        # حجم النصوص/التباين السريع + عدد العناصر
        stats = await page.evaluate("""() => ({
            sections: document.querySelectorAll('section').length,
            links: document.querySelectorAll('a').length,
            buttons: document.querySelectorAll('button').length,
            imgs: document.querySelectorAll('img').length,
            h1: document.querySelectorAll('h1').length,
            cssRules: [...document.styleSheets].reduce((a,s)=>{try{return a+s.cssRules.length}catch(e){return a}},0),
        })""")
        check("بنية الصفحة (h1 واحد)", stats["h1"] == 1, stats)

        print("\nCONSOLE-ERRORS:", [c for c in console if c[0] == "error"][:5])
        total = len(results); passed = sum(1 for r in results if r[1])
        print("\n===== %d/%d ناجح =====" % (passed, total))
        for n, ok, ex in results:
            if not ok: print("  ✗", n, ex)
        await browser.close()
        return 0 if passed == total else 1

sys.exit(asyncio.run(main()))

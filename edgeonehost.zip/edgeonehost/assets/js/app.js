/* =====================================================================
   EdgeOneHost — app.js
   محطة التحكم: رفع الملفات، فحص الكود، التحقق الحقيقي من التوكن عبر
   Telegram Bot API، السجل، المحاكي، وفحص الموقع/الاستضافة.
   ===================================================================== */
(function () {
  "use strict";

  /* ============================ أدوات عامة ============================ */
  const $ = (sel, root) => (root || document).querySelector(sel);
  const $$ = (sel, root) => Array.prototype.slice.call((root || document).querySelectorAll(sel));
  const sleep = (ms) => new Promise(r => setTimeout(r, ms));
  const esc = (s) => String(s == null ? "" : s)
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;").replace(/'/g, "&#39;");
  const pad2 = n => String(n).padStart(2, "0");
  const stamp = () => { const d = new Date(); return pad2(d.getHours()) + ":" + pad2(d.getMinutes()) + ":" + pad2(d.getSeconds()); };
  const fmtBytes = b => b < 1024 ? b + " B" : b < 1048576 ? (b / 1024).toFixed(1) + " KB" : (b / 1048576).toFixed(2) + " MB";
  const uid = () => "f" + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

  const LS = {
    get(k, d) { try { const v = localStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } },
    set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); return true; } catch (e) { return false; } },
    del(k) { try { localStorage.removeItem(k); } catch (e) { } }
  };

  const K_TOKEN = "eoh.token.v1";
  const K_OWNER = "eoh.owner.v1";
  const K_FILES = "eoh.files.v1";
  const TOKEN_RE = /^\d{5,12}:[A-Za-z0-9_-]{30,}$/;

  /* ============================ الحالة ============================ */
  const state = {
    files: [],
    activeId: null,
    token: "",
    owner: "",
    botInfo: null,
    tokenOk: false,
    analysis: null,
    profile: null,
    running: false,
    simStarted: false
  };

  const samples = (window.BotSim && window.BotSim.samples) || {};

  function activeFile() { return state.files.find(f => f.id === state.activeId) || null; }

  /* ============================ توست ============================ */
  const toastWrap = $("#toastWrap");
  function toast(msg, type, ms) {
    type = type || "info";
    const icons = { ok: "✓", err: "✕", warn: "!", info: "i" };
    const el = document.createElement("div");
    el.className = "toast " + type;
    el.innerHTML = '<span class="t-ic">' + (icons[type] || "i") + "</span><span>" + esc(msg) + "</span>";
    toastWrap.appendChild(el);
    const ttl = ms || 3400;
    setTimeout(() => {
      el.style.transition = "opacity .25s, transform .25s";
      el.style.opacity = "0"; el.style.transform = "translateY(8px)";
      setTimeout(() => el.remove(), 260);
    }, ttl);
  }

  /* ============================ سجل ============================ */
  const logBox = $("#logBox");
  function log(msg, cls) {
    if (!logBox) return;
    const line = document.createElement("div");
    line.className = "l-line";
    line.innerHTML = '<span class="l-time">[' + stamp() + "]</span> " +
      '<span class="' + (cls || "l-out") + '">' + esc(msg) + "</span>";
    logBox.appendChild(line);
    logBox.scrollTop = logBox.scrollHeight;
    while (logBox.children.length > 400) logBox.removeChild(logBox.firstChild);
  }
  function logSep(title) {
    if (!logBox) return;
    const line = document.createElement("div");
    line.style.margin = "8px 0";
    line.style.borderTop = "1px dashed #22304c";
    line.style.paddingTop = "6px";
    line.innerHTML = '<span style="color:#6b7d9c">── ' + esc(title) + " ──</span>";
    logBox.appendChild(line);
    logBox.scrollTop = logBox.scrollHeight;
  }

  /* ============================ تلوين بايثون ============================ */
  const PY_KW = ("False None True and as assert async await break class continue def del elif else except finally for from global if import in " +
    "is lambda nonlocal not or pass raise return try while with yield match case").split(" ");
  const PY_BI = ("print len range str int float list dict set tuple bool open input enumerate zip map filter sum min max abs sorted " +
    "isinstance type super object Exception ValueError TypeError KeyError RuntimeError").split(" ");

  function highlightPython(code) {
    const src = String(code || "");
    let out = "";
    let i = 0;
    const n = src.length;
    const isIdStart = c => /[A-Za-z_]/.test(c);
    const isId = c => /[A-Za-z0-9_]/.test(c);

    while (i < n) {
      const c = src[i];
      // تعليق
      if (c === "#") {
        let j = src.indexOf("\n", i); if (j === -1) j = n;
        out += '<span class="cm">' + esc(src.slice(i, j)) + "</span>";
        i = j; continue;
      }
      // نص ثلاثي
      if (c === '"' || c === "'") {
        const triple = src.substr(i, 3);
        if (triple === '"""' || triple === "'''") {
          let j = src.indexOf(triple, i + 3);
          j = j === -1 ? n : j + 3;
          out += '<span class="st">' + esc(src.slice(i, j)) + "</span>";
          i = j; continue;
        }
        let j = i + 1;
        while (j < n) {
          if (src[j] === "\\") { j += 2; continue; }
          if (src[j] === c) { j++; break; }
          if (src[j] === "\n") break;
          j++;
        }
        out += '<span class="st">' + esc(src.slice(i, j)) + "</span>";
        i = j; continue;
      }
      // رقم
      if (/[0-9]/.test(c)) {
        let j = i;
        while (j < n && /[0-9._xXa-fA-F]/.test(src[j])) j++;
        out += '<span class="nm">' + esc(src.slice(i, j)) + "</span>";
        i = j; continue;
      }
      // مُعرّف
      if (isIdStart(c)) {
        let j = i;
        while (j < n && isId(src[j])) j++;
        const word = src.slice(i, j);
        if (PY_KW.indexOf(word) !== -1) out += '<span class="kw">' + word + "</span>";
        else if (PY_BI.indexOf(word) !== -1) out += '<span class="fn">' + word + "</span>";
        else out += esc(word);
        i = j; continue;
      }
      // ديكوريتر
      if (c === "@" && isIdStart(src[i + 1] || "")) {
        let j = i + 1;
        while (j < n && /[A-Za-z0-9_.]/.test(src[j])) j++;
        out += '<span class="dc">' + esc(src.slice(i, j)) + "</span>";
        i = j; continue;
      }
      out += esc(c);
      i++;
    }
    return out;
  }

  /* ============================ إدارة الملفات ============================ */
  const fileListEl = $("#fileList");
  const editor = $("#editor");
  const editorName = $("#editorName");

  function setActive(id, opts) {
    if (!state.files.some(f => f.id === id)) return;
    state.activeId = id;
    renderFiles();
    const f = activeFile();
    if (f) {
      editor.value = f.code;
      editorName.textContent = f.name;
      if (!opts || !opts.silent) {
        setStatus("idle", "● " + f.name + " جاهز");
      }
    }
    resetAnalysis();
    persistFiles();
  }

  function renderFiles() {
    fileListEl.innerHTML = "";
    if (!state.files.length) {
      fileListEl.innerHTML = '<div class="empty-note">لا توجد ملفات — ارفع ملف .py أو اختر مثالًا.</div>';
      return;
    }
    state.files.forEach(f => {
      const row = document.createElement("div");
      row.className = "file-item" + (f.id === state.activeId ? " active" : "");
      row.setAttribute("role", "button");
      row.tabIndex = 0;
      row.innerHTML =
        '<span class="fi-ic">🐍</span>' +
        '<span class="fi-name" title="' + esc(f.name) + '">' + esc(f.name) + "</span>" +
        '<span class="fi-size">' + fmtBytes(new Blob([f.code]).size) + "</span>" +
        '<button class="fi-del" title="حذف" aria-label="حذف الملف">' +
        '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button>';
      row.addEventListener("click", (e) => {
        if (e.target.closest(".fi-del")) return;
        setActive(f.id);
      });
      row.addEventListener("keydown", (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); setActive(f.id); } });
      row.querySelector(".fi-del").addEventListener("click", (e) => {
        e.stopPropagation();
        removeFile(f.id);
      });
      fileListEl.appendChild(row);
    });
  }

  function addFile(name, code, opts) {
    const clean = String(name || "bot.py").replace(/[\\/:*?"<>|]/g, "_");
    const f = {
      id: uid(),
      name: clean.endsWith(".py") ? clean : clean + ".py",
      code: String(code == null ? "" : code),
      addedAt: Date.now()
    };
    state.files.unshift(f);
    if (state.files.length > 12) state.files.pop();
    setActive(f.id, opts);
    return f;
  }

  function removeFile(id) {
    const i = state.files.findIndex(f => f.id === id);
    if (i === -1) return;
    state.files.splice(i, 1);
    if (state.activeId === id) {
      if (state.files.length) setActive(state.files[0].id);
      else {
        state.activeId = null;
        editor.value = ""; editorName.textContent = "untitled.py";
        setStatus("idle", "○ لا يوجد ملف");
        resetAnalysis();
      }
    } else renderFiles();
    persistFiles();
    toast("تم حذف الملف", "warn", 1800);
  }

  function persistFiles() {
    const slim = state.files.map(f => ({ id: f.id, name: f.name, code: f.code, addedAt: f.addedAt }));
    const total = slim.reduce((s, f) => s + f.code.length, 0);
    if (total > 400000) return;              // لا نُثقل التخزين المحلي
    LS.set(K_FILES, slim);
  }

  /* ============================ الرفع ============================ */
  const dropzone = $("#dropzone");
  const fileInput = $("#fileInput");
  const dzFile = $("#dzFile");

  function openPicker() { fileInput.click(); }
  dropzone.addEventListener("click", openPicker);
  dropzone.addEventListener("keydown", e => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); openPicker(); } });
  fileInput.addEventListener("change", () => {
    handleFiles(fileInput.files);
    fileInput.value = "";
  });
  ["dragenter", "dragover"].forEach(ev => dropzone.addEventListener(ev, e => { e.preventDefault(); dropzone.classList.add("over"); }));
  ["dragleave", "dragend"].forEach(ev => dropzone.addEventListener(ev, () => dropzone.classList.remove("over")));
  dropzone.addEventListener("drop", e => {
    e.preventDefault(); dropzone.classList.remove("over");
    if (e.dataTransfer && e.dataTransfer.files) handleFiles(e.dataTransfer.files);
  });

  function handleFiles(list) {
    if (!list || !list.length) return;
    const files = Array.prototype.slice.call(list);
    let accepted = 0;
    files.forEach(file => {
      if (file.size > 1024 * 1024) { toast("الملف " + file.name + " أكبر من 1MB", "warn"); return; }
      const reader = new FileReader();
      reader.onload = () => {
        const code = String(reader.result || "");
        if (!/\.py$/i.test(file.name) && !/python|text\/plain/.test(file.type)) {
          toast("تم قبول ملف غير بايثون للعرض فقط: " + file.name, "warn");
        }
        addFile(file.name, code);
        dzFile.textContent = file.name + " • " + fmtBytes(file.size);
        toast("تم رفع " + file.name, "ok");
        log("📂 تم تحميل الملف: " + file.name + " (" + fmtBytes(file.size) + ")", "l-sys");
        runAnalysisAndRender();
        simReset(true);
      };
      reader.readAsText(file, "utf-8");
      accepted++;
    });
    if (!accepted) toast("لم يتم اختيار أي ملف", "warn");
  }

  /* ============================ المحرر ============================ */
  editor.addEventListener("input", () => {
    const f = activeFile();
    if (!f) return;
    f.code = editor.value;
    persistFiles();
    clearTimeout(editor._t);
    editor._t = setTimeout(() => { runAnalysisAndRender(); }, 500);
  });

  $("#btnFormat").addEventListener("click", () => {
    let v = editor.value.replace(/\t/g, "    ")
      .split("\n").map(l => l.replace(/[ \t]+$/, "")).join("\n");
    if (v && !v.endsWith("\n")) v += "\n";
    editor.value = v;
    const f = activeFile(); if (f) { f.code = v; persistFiles(); }
    runAnalysisAndRender();
    toast("تم تنظيف الكود (مسافات/تابات)", "ok", 2000);
  });

  $("#btnDownload").addEventListener("click", () => {
    const f = activeFile();
    const code = editor.value;
    if (!code.trim()) { toast("لا يوجد كود للتنزيل", "warn"); return; }
    const name = f ? f.name : "bot.py";
    const blob = new Blob([code], { type: "text/x-python;charset=utf-8" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = name;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 1500);
    toast("تم تنزيل " + name, "ok");
  });

  /* ============================ الفحص (Linter) ============================ */
  function stripStringsAndComments(code) {
    let out = "", i = 0, n = code.length;
    while (i < n) {
      const c = code[i];
      if (c === "#") { let j = code.indexOf("\n", i); if (j === -1) j = n; out += " ".repeat(j - i); i = j; continue; }
      if (c === '"' || c === "'") {
        const q = code.substr(i, 3);
        if (q === '"""' || q === "'''") {
          let j = code.indexOf(q, i + 3); j = j === -1 ? n : j + 3;
          out += " ".repeat(Math.max(0, j - i)); i = j; continue;
        }
        let j = i + 1;
        while (j < n) {
          if (code[j] === "\\") { j += 2; continue; }
          if (code[j] === c) { j++; break; }
          if (code[j] === "\n") break;
          j++;
        }
        out += " ".repeat(Math.max(0, j - i)); i = j; continue;
      }
      out += c; i++;
    }
    return out;
  }

  function bracketBalance(clean) {
    const pairs = { "(": ")", "[": "]", "{": "}" };
    const stack = [];
    let line = 1;
    for (let i = 0; i < clean.length; i++) {
      const c = clean[i];
      if (c === "\n") line++;
      if (pairs[c]) stack.push({ c: c, line: line });
      else if (c === ")" || c === "]" || c === "}") {
        const top = stack.pop();
        if (!top || pairs[top.c] !== c) return { ok: false, msg: "قوس مغلق بلا فتح مطابق في السطر " + line };
      }
    }
    if (stack.length) return { ok: false, msg: "قوس غير مغلق (" + stack[stack.length - 1].c + ") من السطر " + stack[stack.length - 1].line };
    return { ok: true };
  }

  function missingColons(code) {
    const clean = stripStringsAndComments(code).split("\n");
    const bad = [];
    const head = /^\s*(?:async\s+)?(def|class|if|elif|else|for|while|try|except|finally|with)\b/;
    clean.forEach((raw, idx) => {
      const line = raw.trimEnd();
      if (!line.trim() || head.test(line) === false) return;
      const t = line.trim();
      // أسطر تتابع على أسطر أخرى
      if (/[\\,(\[{]$/.test(t)) return;
      if (t.endsWith(":")) return;
      if (/^\s*(if|elif|while|for|with|except)\b/.test(t) && /\)\s*$/.test(t) && !t.endsWith(":")) {
        bad.push(idx + 1); return;
      }
      bad.push(idx + 1);
    });
    return bad;
  }

  function analyze(code) {
    const findings = [];
    const add = (sev, title, desc, cat) => findings.push({ sev: sev, title: title, desc: desc, cat: cat || "quality" });
    const src = String(code || "");
    const lines = src.split(/\r?\n/);
    const clean = stripStringsAndComments(src);
    const prof = (window.BotSim ? window.BotSim.profile(src) : { framework: { id: "none", title: "غير معروف" }, commands: [], handlers: {}, imports: [], usesPolling: false, usesWebhook: false, tokenLiteral: null, tokenFromEnv: false, hasMain: false, echo: false });

    /* --- 1) الأساسيات --- */
    if (!src.trim()) {
      add("fail", "الملف فارغ", "لا يوجد كود لفحصه. ارفع ملف .py أو اختر مثالًا جاهزًا من اللوحة اليمنى.", "syntax");
      return finalize(findings, prof, src);
    }
    add("pass", "الملف غير فارغ", prof.lines + " سطرًا • " + fmtBytes(new Blob([src]).size) + " • ترميز UTF-8.", "base");

    if (new Blob([src]).size > 300 * 1024) {
      add("warn", "حجم الملف كبير", "ملفات أكبر من 300KB تُبطئ التشغيل على الدوال السحابية. الأفضل تقسيم المشروع إلى وحدات.", "base");
    }

    /* --- 2) الصياغة --- */
    const bal = bracketBalance(clean);
    if (bal.ok) add("pass", "الأقواس متوازنة", "لا توجد أقواس غير مغلقة داخل الكود.", "syntax");
    else add("fail", "أقواس غير متوازنة", bal.msg + " — سيرفض مفسّر بايثون الملف برسالة SyntaxError.", "syntax");

    const noColon = missingColons(src);
    if (!noColon.length) add("pass", "النقطتان الرأسيتان سليمة", "كل تعريفات الدوال والشروط تنتهي بـ «:».", "syntax");
    else add("fail", "نقطتان رأسيتان ناقصتان", "الأسطر " + noColon.slice(0, 6).join("، ") + " تحتاج «:» في نهايتها. مثال: <code>def start(message):</code>", "syntax");

    if (/^\s*print\s+[^(=]/m.test(clean)) {
      add("warn", "صياغة Python 2", "السطر يبدو بصيغة <code>print &quot;x&quot;</code> القديمة. استخدم <code>print(&quot;x&quot;)</code> لتوافق Python 3.", "syntax");
    } else add("pass", "متوافق مع Python 3", "لم تظهر أي صياغة من Python 2.", "syntax");

    const tabLines = lines.filter(l => /^\t+ /.test(l) || /^ +\t/.test(l)).length;
    if (tabLines) add("warn", "خلط تابات ومسافات", tabLines + " سطرًا يخلط بينهما، وقد يسبب IndentationError. شغّل زر «تنسيق».", "syntax");
    else add("pass", "الإزاحة متسقة", "لا يوجد خلط بين التابات والمسافات.", "syntax");

    /* --- 3) المكتبة والإطار --- */
    if (prof.framework.id === "none") {
      add("fail", "لا توجد مكتبة بوت معروفة", "لم يتم العثور على <code>telebot</code> أو <code>aiogram</code> أو <code>python-telegram-bot</code>. تأكد من الاستيراد الصحيح.", "framework");
    } else {
      const note = prof.framework.id === "telebot" ? "pip install pyTelegramBotAPI" :
        prof.framework.id === "aiogram" ? "pip install aiogram" :
          prof.framework.id === "ptb" ? "pip install python-telegram-bot" : "استدعاء HTTP مباشر لواجهة تلغرام";
      add("pass", "مكتبة البوت: " + prof.framework.title, "التثبيت المطلوب: <code>" + note + "</code>", "framework");
    }

    if (/(TeleBot\s*\(|Bot\s*\(|ApplicationBuilder|Dispatcher\s*\()/.test(src)) {
      add("pass", "كائن البوت مُهيّأ", "تم إنشاء نسخة البوت/المُوزّع كما يجب.", "framework");
    } else {
      add("warn", "لا يوجد كائن بوت", "لم أجد <code>TeleBot()</code> أو <code>Bot()</code>؛ قد يكون الكود مُجزّأً بين ملفات.", "framework");
    }

    /* --- 4) المعالجات --- */
    const handlerCount = prof.blocks.length + (/(add_handler|register_message_handler|register_next_step_handler)/.test(src) ? 1 : 0);
    if (handlerCount > 0) add("pass", "معالجات الرسائل موجودة", "عدد المعالجات المكتشفة: " + handlerCount + ".", "handlers");
    else add("fail", "لا توجد معالجات", "البوت لن يردّ على أي رسالة. أضف <code>@bot.message_handler(commands=[\"start\"])</code>.", "handlers");

    if (prof.commands.indexOf("start") !== -1) add("pass", "أمر /start موجود", "سيظهر زر «ابدأ» للمستخدمين بشكل صحيح.", "handlers");
    else add("warn", "لا يوجد أمر /start", "معظم المستخدمين يبدأون بـ /start. إضافته تحسّن التجربة الأولى.", "handlers");

    if (prof.commands.indexOf("help") !== -1) add("pass", "أمر /help موجود", "قائمة المساعدة متاحة للمستخدم.", "handlers");
    else add("warn", "لا يوجد أمر /help", "أضف /help لتقليل أسئلة المستخدمين عن طريقة الاستخدام.", "handlers");

    if (prof.echo) add("pass", "معالج عام للنصوص", "البوت يستجيب لأي نص (مناسب للبوتات التجريبية).", "handlers");

    /* --- 5) الأمان --- */
    if (prof.tokenLiteral) {
      add("fail", "توكن مكتوب داخل الكود", "تم العثور على توكن بصيغة صحيحة داخل الملف (<code>" +
        esc(prof.tokenLiteral.slice(0, 10)) + "…</code>). أي شخص يحصل على الملف يستطيع التحكم ببوتك. استخدم متغيّر بيئة <code>BOT_TOKEN</code>.", "security");
    } else if (prof.tokenFromEnv) {
      add("pass", "التوكن من متغيّر بيئة", "يُقرأ من <code>os.environ</code> — أفضل ممارسة أمنية.", "security");
    } else {
      add("warn", "لم أجد مصدرًا للتوكن", "لا يوجد توكن في الكود ولا في متغيّر بيئة. أضف <code>BOT_TOKEN</code> في إعدادات الاستضافة.", "security");
    }

    if (/(os\.system|subprocess\.(?:call|run|Popen)|pty\.spawn)\s*\(/.test(src)) {
      add("fail", "تنفيذ أوامر نظام", "استخدام <code>os.system</code> أو <code>subprocess</code> خطر على الاستضافة ويُرفض في معظم المنصات.", "security");
    }
    if (/(?<![A-Za-z_.])eval\s*\(|(?<![A-Za-z_.])exec\s*\(/.test(src)) {
      add("warn", "استخدام eval/exec", "تنفيذ كود ديناميكي يفتح ثغرة حقن. تجنّبه إن أمكن.", "security");
    }
    if (/(password|passwd|api_key|secret_key)\s*=\s*["'][^"']{6,}["']/i.test(src)) {
      add("fail", "أسرار مكتوبة في الكود", "يوجد ما يبدو أنه كلمة مرور أو مفتاح API داخل الكود. انقلها إلى متغيّرات بيئة.", "security");
    } else {
      add("pass", "لا أسرار إضافية ظاهرة", "لم تظهر كلمات مرور أو مفاتيح مكتوبة مباشرة.", "security");
    }
    if (/verify\s*=\s*False/.test(src)) add("warn", "تعطيل التحقق من TLS", "<code>verify=False</code> يعرّض الاتصال لهجمات الوسيط.", "security");
    if (/(chat_id\s*=\s*["']?-?\d{6,})/.test(src)) add("warn", "معرّف محادثة ثابت", "وجود <code>chat_id</code> مكتوب يدويًا يمنع البوت من العمل لمستخدمين آخرين.", "security");

    /* --- 6) الموثوقية --- */
    const hasTry = /try\s*:/.test(src);
    if (hasTry) add("pass", "معالجة أخطاء", "يوجد <code>try/except</code> لتجنّب توقف البوت عند خطأ عابر.", "quality");
    else add("warn", "لا معالجة أخطاء", "أضف <code>try/except</code> حول أوامر الشبكة حتى لا يتوقف البوت بسبب استثناء واحد.", "quality");

    const busyLoop = /while\s+(?:True|1)\s*:(?:[^\n]*)\n\s*(?:pass|continue)\b/.test(src) ||
      /for\s+_?\s+in\s+itertools\.repeat\(\)\s*:\s*\n\s*pass\b/.test(src);
    if (busyLoop) add("fail", "حلقة لا نهائية فارغة", "<code>while True: pass</code> تستهلك 100% من المعالج وتُجمّد البوت. احذفها أو استبدلها بـ <code>bot.infinity_polling()</code>.", "quality");
    else add("pass", "لا حلقات مشغولة", "لم تظهر حلقات انتظار نشطة تلتهم المعالج.", "quality");

    if (/except\s*:\s*(?:\n\s*pass\b|#)/.test(src) || /except\s*:\s*\n/.test(src)) {
      add("warn", "except عام بدون نوع", "استخدام <code>except:</code> يخفي كل الأخطاء. حدّد النوع: <code>except Exception as e:</code> وسجّل الخطأ.", "quality");
    }
    if (/except[^\n]*:\s*\n\s*pass\b/.test(src)) {
      add("warn", "ابتلاع الأخطاء (pass)", "وجود <code>except: pass</code> يجعل تشخيص المشكلات مستحيلًا. سجّل الخطأ على الأقل.", "quality");
    }
    if (/os\.getenv\(\s*["']BOT_TOKEN["']\s*\)\s*$|os\.environ\.get\(\s*["']BOT_TOKEN["']\s*,\s*["']{2}\s*\)/.test(src)) {
      add("warn", "لا تحقق من غياب التوكن", "إذا كان <code>BOT_TOKEN</code> فارغًا سيرمي البوت استثناءً غامضًا. أضف فحصًا مبكرًا ورسالة واضحة.", "quality");
    }
    if (/(?:time\.sleep|asyncio\.sleep)\(\s*(?:[3-9]\d|\d{3,})\s*\)/.test(src)) {
      add("warn", "انتظار طويل داخل المعالج", "استخدام <code>sleep</code> لثوانٍ طويلة داخل معالج رسالة يبطئ البوت ويستهلك مدة تنفيذ الدالة السحابية.", "quality");
    }

    if (/(requests\.(get|post)\([^)]*)\)/.test(src) && !/timeout\s*=/.test(src)) {
      add("warn", "طلبات بلا timeout", "استدعاءات <code>requests</code> بدون <code>timeout</code> قد تعلّق البوت إلى الأبد.", "quality");
    }
    if (prof.hasMain) add("pass", "نقطة دخول واضحة", "يوجد <code>if __name__ == \"__main__\":</code> لتشغيل الملف مباشرة.", "quality");
    else add("warn", "لا نقطة دخول", "أضف <code>if __name__ == \"__main__\":</code> لتشغيل الكود عند تنفيذ الملف.", "quality");

    if (/print\s*\(/.test(src) || /logging\./.test(src)) add("pass", "سجلات/طباعة موجودة", "ستظهر الرسائل في سجل الاستضافة لتتابع حالة البوت.", "quality");
    else add("warn", "لا سجلات", "أضف <code>print</code> أو <code>logging</code> لتشخيص المشكلات بسرعة.", "quality");

    /* --- 7) التوافق مع الاستضافة --- */
    if (prof.usesPolling && !prof.usesWebhook) {
      add("warn", "وضع Polling دائم", "يستخدم هذا الملف <code>infinity_polling</code>/<code>polling()</code>، وهو يحتاج عملية حيّة دائمة. على EdgeOne Pages (Serverless) لن يعمل — استخدم نسخة Webhook.", "hosting");
    } else if (prof.usesWebhook) {
      add("pass", "جاهز لـ Webhook", "الكود يتضمن Webhook/سيرفر HTTP، وهو النمط المناسب للاستضافة السحابية.", "hosting");
    }
    if (/\.env|dotenv/.test(src)) add("pass", "يدعم ملف .env", "يمكنك إدارة الأسرار من لوحة الاستضافة أو ملف <code>.env</code>.", "hosting");
    if (prof.imports.some(i => /^(sqlite3|shelve|pickle)$/.test(i))) {
      add("warn", "تخزين ملفات محلية", "SQLite/الملفات لا تبقى بين الطلبات على الدوال السحابية. استخدم قاعدة بيانات خارجية.", "hosting");
    }

    return finalize(findings, prof, src);
  }

  function finalize(findings, prof, src) {
    const counts = { pass: 0, warn: 0, fail: 0 };
    findings.forEach(f => counts[f.sev]++);
    let score;
    if (!String(src || "").trim()) score = 0;
    else score = clamp(100 - counts.fail * 11 - counts.warn * 3, 4, 100);
    const grade = score >= 85 ? "جاهز للتشغيل" : score >= 60 ? "يحتاج تحسينات" : score >= 35 ? "مشاكل مهمة" : "غير صالح";
    return { findings: findings, counts: counts, score: score, grade: grade, profile: prof };
  }

  /* ============================ عرض الفحص ============================ */
  const findingsEl = $("#findings");
  const ring = $("#ring");
  const ringVal = $("#ringVal");
  const scoreTitle = $("#scoreTitle");
  const scoreDesc = $("#scoreDesc");
  const scoreChips = $("#scoreChips");
  const checkBadge = $("#checkBadge");
  const codeBadge = $("#codeBadge");

  function resetAnalysis() {
    state.analysis = null;
    if (findingsEl) findingsEl.innerHTML = "";
    if (ring) { ring.style.setProperty("--p", 0); ring.style.setProperty("--c", "var(--brand)"); }
    if (ringVal) ringVal.innerHTML = "—<small>/100</small>";
    if (scoreTitle) scoreTitle.textContent = "لم يتم الفحص بعد";
    if (scoreDesc) scoreDesc.textContent = "ارفع ملفًا ثم اضغط «تشغيل» أو انتظر الفحص التلقائي.";
    if (scoreChips) scoreChips.innerHTML = "";
    if (checkBadge) checkBadge.className = "badge-n hide";
    if (codeBadge) codeBadge.className = "badge-n hide";
  }

  function renderAnalysis(res) {
    state.analysis = res;
    const nPass = res.counts.pass, nWarn = res.counts.warn, nFail = res.counts.fail;
    const color = res.score >= 85 ? "var(--ok)" : res.score >= 60 ? "var(--warn)" : "var(--bad)";
    if (ring) {
      ring.style.setProperty("--p", res.score);
      ring.style.setProperty("--c", color);
    }
    if (ringVal) ringVal.innerHTML = res.score + '<small>/100</small>';
    if (scoreTitle) scoreTitle.textContent = res.grade;
    if (scoreDesc) {
      const fr = res.profile && res.profile.framework ? res.profile.framework.title : "—";
      scoreDesc.innerHTML = "الإطار: <b>" + esc(fr) + "</b> • " + (res.profile ? res.profile.commands.length : 0) +
        " أمرًا مكتشفًا • " + (res.profile ? res.profile.lines : 0) + " سطرًا";
    }
    if (scoreChips) {
      scoreChips.innerHTML =
        '<span class="chip ok">' + nPass + " ناجح</span>" +
        '<span class="chip warn">' + nWarn + " تحذير</span>" +
        '<span class="chip fail">' + nFail + " خطأ</span>";
    }
    if (findingsEl) {
      const order = { fail: 0, warn: 1, pass: 2 };
      const html = res.findings.slice().sort((a, b) => order[a.sev] - order[b.sev]).map(f => {
        const ic = f.sev === "pass" ? "✓" : f.sev === "warn" ? "!" : "✕";
        return '<div class="finding ' + f.sev + '"><span class="f-ic">' + ic + '</span><div class="f-body">' +
          '<div class="f-title">' + esc(f.title) + "</div>" +
          '<div class="f-desc">' + f.desc + "</div></div></div>";
      }).join("");
      findingsEl.innerHTML = html;
    }
    const issueCount = nFail + nWarn;
    if (checkBadge) {
      checkBadge.className = "badge-n" + (issueCount === 0 ? " ok" : "");
      checkBadge.textContent = issueCount === 0 ? "✓" : String(issueCount);
    }
    if (codeBadge) {
      codeBadge.className = "badge-n" + (nFail === 0 ? " ok" : "");
      codeBadge.textContent = nFail === 0 ? "✓" : String(nFail);
    }
  }

  function runAnalysisAndRender() {
    const f = activeFile();
    if (!f) { resetAnalysis(); return null; }
    f.code = editor.value;
    const res = analyze(f.code);
    renderAnalysis(res);
    const prof = res.profile;
    state.profile = prof;
    return res;
  }

  /* ============================ التبويبات ============================ */
  const tabs = $$(".tab");
  function switchTab(name) {
    tabs.forEach(t => t.classList.toggle("active", t.dataset.tab === name));
    $$(".panel").forEach(p => { p.hidden = p.dataset.panel !== name; });
    if (name === "console") logBox.scrollTop = logBox.scrollHeight;
    if (name === "check" && !state.analysis) runAnalysisAndRender();
    if (name === "sim") { /* المحاكي قسم منفصل بالأسفل */ }
  }
  tabs.forEach(t => t.addEventListener("click", () => switchTab(t.dataset.tab)));

  /* ============================ الحالة ============================ */
  const statusPill = $("#statusPill");
  function setStatus(kind, text) {
    if (!statusPill) return;
    statusPill.className = "status-pill " + kind;
    statusPill.textContent = text;
  }

  /* ============================ تلغرام API ============================ */
  async function tgCall(method, token, payload) {
    const url = "https://api.telegram.org/bot" + token + "/" + method;
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 15000);
    try {
      const res = await fetch(url, {
        method: payload ? "POST" : "GET",
        headers: payload ? { "Content-Type": "application/json" } : undefined,
        body: payload ? JSON.stringify(payload) : undefined,
        signal: ctrl.signal,
        cache: "no-store"
      });
      const data = await res.json().catch(() => null);
      return { http: res.status, data: data };
    } catch (e) {
      return { error: e.name === "AbortError" ? "انتهت مدة الانتظار (15 ثانية)" : (e.message || "فشل الاتصال"), offline: true };
    } finally {
      clearTimeout(timer);
    }
  }

  function renderBotCard(info) {
    const av = $("#bpAvatar"), nm = $("#bpName"), us = $("#bpUser"), hint = $("#bpHint");
    if (info) {
      av.textContent = (info.first_name || "B").trim().charAt(0).toUpperCase();
      nm.textContent = (info.first_name || "") + (info.last_name ? " " + info.last_name : "");
      us.textContent = "@" + (info.username || "—") + " • id: " + info.id;
      hint.innerHTML = '<span class="badge ok">✔ متصل</span> بوت حقيقي تم التحقق منه عبر <code>getMe</code>. ' +
        (info.can_join_groups ? "يمكن إضافته للمجموعات." : "غير مسموح بإضافته للمجموعات حاليًا.");
    } else {
      av.textContent = "?";
      nm.textContent = "لا يوجد بوت متصل";
      us.textContent = "@unknown";
      hint.textContent = "أدخل توكنًا صحيحًا واضغط «تحقق من التوكن» لعرض بيانات البوت الحقيقية من تلغرام.";
    }
  }

  const tokenInput = $("#tokenInput");
  const tokenHint = $("#tokenHint");
  const persistToken = $("#persistToken");

  async function verifyToken(opts) {
    opts = opts || {};
    const token = (opts.token || tokenInput.value || "").trim();
    if (!token) { toast("أدخل توكن البوت أولًا", "warn"); tokenInput.focus(); return null; }
    if (!TOKEN_RE.test(token)) {
      state.tokenOk = false;
      tokenHint.innerHTML = '<span style="color:#ff8a95">الصيغة غير صحيحة: التوكن يشبه <span class="mono">123456789:AA...</span> (رقم، نقطتان، 35 حرفًا).</span>';
      if (!opts.silent) toast("صيغة التوكن غير صحيحة", "err");
      log("✕ صيغة التوكن غير صحيحة", "l-err");
      return { ok: false, reason: "format" };
    }
    setStatus("running", "◌ جارٍ التحقق…");
    log("→ GET /getMe على api.telegram.org", "l-info");
    const r = await tgCall("getMe", token);
    if (r.error) {
      state.tokenOk = false;
      setStatus("bad", "✕ تعذّر الاتصال بتلغرام");
      log("✕ " + r.error + " — تحقق من اتصال الإنترنت أو حظر الشبكة.", "l-err");
      tokenHint.innerHTML = '<span style="color:#ff8a95">تعذّر الوصول إلى api.telegram.org.</span>';
      if (!opts.silent) toast("تعذّر الاتصال بتلغرام", "err");
      return { ok: false, reason: "network" };
    }
    const d = r.data;
    if (d && d.ok && d.result) {
      state.tokenOk = true;
      state.token = token;
      state.botInfo = d.result;
      tokenHint.innerHTML = '<span style="color:#4ee0a8">✔ توكن صحيح — @' + esc(d.result.username || "") + "</span>";
      setStatus("ok", "● متصل بـ @" + (d.result.username || "bot"));
      renderBotCard(d.result);
      log("✔ 200 OK — البوت: " + (d.result.first_name || "") + " (@" + (d.result.username || "?") + ") id=" + d.result.id, "l-ok");
      if (persistToken && persistToken.checked) LS.set(K_TOKEN, token);
      else LS.del(K_TOKEN);
      if (!opts.silent) toast("تم التحقق من البوت: @" + (d.result.username || ""), "ok");
      return { ok: true, info: d.result };
    }
    state.tokenOk = false;
    state.botInfo = null;
    renderBotCard(null);
    const desc = (d && d.description) || "توكن غير صالح";
    const code401 = r.http === 401 || (d && d.error_code === 401);
    tokenHint.innerHTML = '<span style="color:#ff8a95">✕ ' + esc(desc) + "</span>";
    setStatus("bad", "✕ توكن مرفوض");
    log("✕ " + r.http + " — " + desc + (code401 ? " (التوكن محذوف أو مُعاد توليده)" : ""), "l-err");
    if (!opts.silent) toast("تلغرام رفض التوكن: " + desc, "err", 5000);
    return { ok: false, reason: "rejected", desc: desc };
  }

  $("#btnVerify").addEventListener("click", () => verifyToken());

  $("#btnSendTest").addEventListener("click", async () => {
    if (!state.tokenOk || !state.botInfo) {
      const v = await verifyToken();
      if (!v || !v.ok) return;
    }
    const owner = ($("#ownerInput").value || "").trim();
    if (!/^-?\d{5,15}$/.test(owner)) { toast("أدخل معرّف حسابك الرقمي (chat_id)", "warn"); $("#ownerInput").focus(); return; }
    const text = ($("#testMsgInput").value || "✅ البوت يعمل").slice(0, 4000);
    const btn = $("#btnSendTest");
    btn.disabled = true; btn.textContent = "⏳ جارٍ الإرسال…";
    log("→ sendMessage إلى chat_id=" + owner, "l-info");
    const r = await tgCall("sendMessage", state.token, { chat_id: owner, text: text });
    btn.disabled = false; btn.innerHTML = "📨 إرسال رسالة (تستهلك صلاحية الإرسال)";
    if (r.error) { log("✕ " + r.error, "l-err"); toast(r.error, "err"); return; }
    if (r.data && r.data.ok) {
      log("✔ تم إرسال الرسالة بنجاح إلى " + owner, "l-ok");
      toast("تم إرسال الرسالة إلى تلغرام ✓", "ok");
      simAdd("bot", "📨 (رسالة تجربة أُرسلت إلى تلغرام) " + text);
      switchTab("preview");
    } else {
      const desc = (r.data && r.data.description) || "فشل الإرسال";
      let extra = "";
      if (/can't initiate conversation|bot was blocked|chat not found/i.test(desc))
        extra = " — يجب أن تفتح البوت في تلغرام وتضغط «Start» أولًا.";
      log("✕ " + desc + extra, "l-err");
      toast(desc + extra, "err", 6000);
    }
  });

  /* ============================ التشغيل ============================ */
  const btnRun = $("#btnRun");

  async function runBot() {
    if (state.running) return;
    const f = activeFile();
    const code = editor.value;
    if (!f || !code.trim()) { toast("ارفع ملف .py أولًا أو اختر مثالًا جاهزًا", "err"); switchTab("code"); return; }

    state.running = true;
    btnRun.disabled = true; btnRun.innerHTML = "⏳ جارٍ التنفيذ…";
    setStatus("running", "◌ جارٍ التشغيل…");
    switchTab("console");
    logSep("تشغيل جديد");
    log("$ python " + f.name, "l-sys");
    await sleep(220);
    log("Python 3.11.9 (main) — EdgeOneHost Runner v1.0", "l-info");

    const res = analyze(code);
    renderAnalysis(res);
    const prof = res.profile;
    state.profile = prof;

    await sleep(260);
    if (prof.imports.length) log("[import] " + prof.imports.join(", "), "l-info");
    await sleep(200);

    // 1) فشل صياغة → إيقاف
    const syntaxFails = res.findings.filter(x => x.sev === "fail" && x.cat === "syntax");
    if (syntaxFails.length) {
      syntaxFails.forEach(x => log("SyntaxError: " + x.title + " — " + x.desc.replace(/<[^>]+>/g, ""), "l-err"));
      log("✕ توقف التشغيل: أصلح أخطاء الصياغة أولًا.", "l-err");
      setStatus("bad", "✕ فشل التشغيل — أخطاء صياغة");
      toast("فشل التشغيل: " + syntaxFails.length + " خطأ في الصياغة", "err", 5000);
      finishRun(); switchTab("check");
      return;
    }
    log("✔ تم تحليل الملف: " + prof.lines + " سطرًا، لا أخطاء صياغة", "l-ok");

    // 2) مكتبة
    if (prof.framework.id === "none") {
      log("✕ ModuleNotFoundError: لم يتم العثور على مكتبة بوت (telebot / aiogram / telegram.ext)", "l-err");
      log("  ثبّت المكتبة: pip install pyTelegramBotAPI | aiogram | python-telegram-bot", "l-warn");
      setStatus("bad", "✕ مكتبة البوت غير موجودة");
      toast("أضف استيراد مكتبة بوت إلى الملف", "err");
      finishRun(); return;
    }
    log("✔ المكتبة: " + prof.framework.title, "l-ok");

    if (!prof.blocks.length) log("⚠ لا توجد معالجات رسائل — البوت لن يردّ على شيء.", "l-warn");
    else log("✔ تم تسجيل " + prof.blocks.length + " معالج رسائل" + (prof.commands.length ? ": /" + prof.commands.join(" /") : ""), "l-ok");

    await sleep(280);

    // 3) التوكن
    const token = prof.tokenLiteral || state.token || tokenInput.value.trim();
    if (prof.tokenLiteral) {
      log("⚠ تحذير أمني: التوكن مكتوب داخل الكود. انقله إلى متغيّر بيئة BOT_TOKEN.", "l-warn");
    }
    if (!token) {
      log("✕ لم يتم العثور على توكن. أضفه في خانة «توكن البوت» أو عبر BOT_TOKEN.", "l-err");
      setStatus("warn", "⚠ البوت بلا توكن");
      toast("أدخل توكن البوت ثم أعد التشغيل", "warn", 4500);
      finishRun(); return;
    }

    log("📡 التحقق من التوكن مع api.telegram.org …", "l-info");
    const vr = await verifyToken({ token: token, silent: true });
    await sleep(200);

    if (vr && vr.ok) {
      log("✔ تم التحقق من البوت — الاتصال بتلغرام سليم.", "l-ok");
      if (prof.usesPolling && !prof.usesWebhook) {
        log("⚠ هذا الملف يستخدم polling دائم: يعمل على VPS/حاويات، ولا يعمل على EdgeOne Pages Serverless.", "l-warn");
        log("  → لـ EdgeOne استخدم نمط Webhook (مجلد edgeone-deploy).", "l-info");
      }
      log("✔ البوت جاهز — جرّب الأوامر في «محاكي البوت» أو أرسل رسالة تجربة.", "l-ok");
      setStatus("ok", "● يعمل — @" + ((state.botInfo && state.botInfo.username) || "bot"));
      toast("البوت جاهز ويعمل ✓", "ok");
      simReset(true);
      switchTab("preview");
    } else if (vr && vr.reason === "rejected") {
      log("⚠ التوكن مرفوض من تلغرام: " + vr.desc, "l-warn");
      log("  شغّلتُ الفحص والمحاكاة فقط. البوت الحقيقي لن يعمل حتى تضع توكنًا صحيحًا.", "l-warn");
      setStatus("warn", "⚠ التوكن مرفوض — وضع المحاكاة");
      toast("التوكن مرفوض — تم تشغيل وضع المحاكاة فقط", "warn", 5000);
      simReset(true);
      switchTab("preview");
    } else {
      log("⚠ تعذّر الوصول إلى تلغرام. تم تشغيل وضع المحاكاة فقط.", "l-warn");
      setStatus("warn", "⚠ وضع المحاكاة (بلا اتصال)");
      simReset(true);
      switchTab("preview");
    }
    finishRun();
  }

  function finishRun() {
    state.running = false;
    btnRun.disabled = false;
    btnRun.innerHTML = "▶ تشغيل";
  }

  btnRun.addEventListener("click", runBot);

  editor.addEventListener("keydown", e => {
    if ((e.ctrlKey || e.metaKey) && e.key === "Enter") { e.preventDefault(); runBot(); }
    if (e.key === "Tab") {
      e.preventDefault();
      const s = editor.selectionStart, en = editor.selectionEnd;
      editor.value = editor.value.slice(0, s) + "    " + editor.value.slice(en);
      editor.selectionStart = editor.selectionEnd = s + 4;
    }
  });

  $("#btnClearLog").addEventListener("click", () => { logBox.innerHTML = ""; log("تم مسح السجل", "l-sys"); });

  /* ============================ المحاكي ============================ */
  const simBody = $("#simBody");
  const simForm = $("#simForm");
  const simInput = $("#simInput");
  const simName = $("#simName");
  const simAvatar = $("#simAvatar");

  function simAdd(text, type) {
    const el = document.createElement("div");
    el.className = "msg " + (type || "bot");
    el.textContent = text;
    simBody.appendChild(el);
    simBody.scrollTop = simBody.scrollHeight;
    while (simBody.children.length > 60) simBody.removeChild(simBody.firstChild);
  }

  function simReset(greet) {
    if (!simBody) return;
    simBody.innerHTML = "";
    const f0 = activeFile();
    const prof = state.profile || (window.BotSim && f0 ? window.BotSim.profile(editor.value) : null);
    if (state.botInfo) {
      simName.innerHTML = esc(state.botInfo.first_name || "Bot") + "<small>@ " + esc(state.botInfo.username || "") + " • متصل</small>";
      simAvatar.textContent = (state.botInfo.first_name || "B").charAt(0).toUpperCase();
    } else {
      simName.innerHTML = 'EdgeOneHost Bot<small>محاكاة • offline</small>';
      simAvatar.textContent = "E";
    }
    state.simStarted = false;
    if (greet) {
      simBody.innerHTML = '<div class="msg sys">بدأت محادثة تجريبية — الرسائل لا تُرسل إلى تلغرام</div>';
      const f = activeFile();
      if (f) simAdd("تم تحميل " + f.name, "sys");
      simAdd("مرحبًا 👋 اكتب /start للبدء.", "bot");
      state.simStarted = true;
    }
  }

  function sendSim() {
    const text = simInput.value.trim();
    if (!text) return;
    simInput.value = "";
    simAdd(text, "user");
    const prof = state.profile || (window.BotSim ? window.BotSim.profile(editor.value) : null);
    if (!prof || !editor.value.trim()) { simAdd("ارفع ملف بوت أولًا في محطة التحكم أعلاه.", "sys"); return; }
    if (!state.simStarted) state.simStarted = true;
    let reply;
    try {
      reply = window.BotSim.buildReply(prof, text, { name: "زائر" });
    } catch (err) {
      reply = { type: "sys", text: "تعذّر توليد الرد: " + err.message };
    }
    if (reply.type === "sys") { simAdd(reply.text, "sys"); return; }
    setTimeout(() => { simAdd(reply.text, "bot"); }, 260);
  }

  // لا نعتمد على submit النموذج فقط: بعض بيئات المعاينة (iframe sandbox) تحجب إرسال النماذج
  simForm.addEventListener("submit", e => { e.preventDefault(); sendSim(); });
  const simBtn = simForm.querySelector('button[type="submit"]');
  if (simBtn) {
    simBtn.type = "button";
    simBtn.addEventListener("click", e => { e.preventDefault(); sendSim(); });
  }
  simInput.addEventListener("keydown", e => {
    if (e.key === "Enter") { e.preventDefault(); sendSim(); }
  });

  /* ============================ أمثلة جاهزة ============================ */
  $$("[data-sample]").forEach(btn => {
    btn.addEventListener("click", () => {
      const key = btn.dataset.sample;
      const s = samples[key];
      if (!s) return;
      addFile(s.name, s.code);
      dzFile.textContent = s.name + " • مثال";
      toast("تم تحميل المثال: " + s.name, "ok");
      log("📂 تم تحميل مثال: " + s.name + " (" + s.label + ")", "l-sys");
      runAnalysisAndRender();
      simReset(true);
      switchTab("code");
    });
  });

  /* ============================ فحص الموقع ============================ */
  const auditOut = $("#auditOut");
  const siteUrl = $("#siteUrl");

  function auditRow(sev, title, desc) {
    const ic = sev === "pass" ? "✓" : sev === "warn" ? "!" : "✕";
    return '<div class="finding ' + sev + '"><span class="f-ic">' + ic + '</span><div class="f-body">' +
      '<div class="f-title">' + esc(title) + "</div><div class=\"f-desc\">" + desc + "</div></div></div>";
  }

  function localAudit() {
    const rows = [];
    const html = document.documentElement.outerHTML;
    const title = (document.title || "").trim();
    const viewport = $('meta[name="viewport"]');
    const desc = $('meta[name="description"]');
    const cssLinks = $$('link[rel="stylesheet"]');
    const scripts = $$("script[src]");
    const ext = $$('script[src],link[href],img[src]')
      .map(el => el.getAttribute("src") || el.getAttribute("href"))
      .filter(u => u && /^https?:\/\//.test(u));

    if (title.length >= 10 && title.length <= 75) rows.push(["pass", "عنوان الصفحة", "الطول " + title.length + " حرفًا — مناسب للفهرسة والمشاركة."]);
    else if (title) rows.push(["warn", "عنوان الصفحة", "الطول " + title.length + " حرفًا. الأفضل بين 10 و75 حرفًا."]);
    else rows.push(["fail", "لا يوجد عنوان", "أضف <code>&lt;title&gt;</code> للصفحة."]);

    if (viewport) rows.push(["pass", "متوافق مع الجوال", 'يوجد <code>meta viewport</code> — الصفحة تتجاوب مع عرض الشاشة.']);
    else rows.push(["fail", "غير متجاوب", "لا يوجد <code>meta viewport</code>؛ الصفحة ستُقصّ على الجوال."]);

    if (desc && (desc.content || "").length >= 50) rows.push(["pass", "وصف تعريفي (SEO)", "طول الوصف " + desc.content.length + " حرفًا."]);
    else rows.push(["warn", "وصف تعريفي ناقص", "أضف <code>meta description</code> بين 50 و160 حرفًا."]);

    if (document.documentElement.lang === "ar" && document.documentElement.dir === "rtl")
      rows.push(["pass", "اللغة والاتجاه", 'مضبوط على <code>lang="ar" dir="rtl"</code> — صحيح للعربية.']);
    else rows.push(["warn", "اللغة والاتجاه", "لم يتم ضبط <code>lang</code> و<code>dir</code> بشكل صحيح."]);

    if (!ext.length) rows.push(["pass", "لا موارد خارجية", "كل الأنماط والسكربتات محلية أو مدمجة، لذا تعمل الصفحة بلا إنترنت."]);
    else rows.push(["warn", "موارد خارجية", "يوجد " + ext.length + " موردًا خارجيًا: <code>" + esc(ext.slice(0, 3).join(", ")) + "</code>"]);

    let mediaCount = 0;
    try {
      Array.prototype.forEach.call(document.styleSheets, sheet => {
        let rules = [];
        try { rules = sheet.cssRules || []; } catch (e) { return; }
        Array.prototype.forEach.call(rules, r => { if (r.type === CSSRule.MEDIA_RULE) mediaCount++; });
      });
    } catch (e) { }
    if (mediaCount >= 3) rows.push(["pass", "نقاط تجاوب", "عدد استعلامات الوسائط (Media Queries): " + mediaCount + "."]);
    else rows.push(["warn", "تجاوب محدود", "استعلامات الوسائط المكتشفة: " + mediaCount + " (يُفضّل 3 فأكثر)."]);

    if (!/on(click|load|error)\s*=/i.test(html)) rows.push(["pass", "لا معالجات مضمّنة", "كل أحداث JS مرتبطة برمجيًا (addEventListener) — أسهل للصيانة والأمان."]);
    else rows.push(["warn", "معالجات مضمّنة", "توجد أحداث HTML مضمّنة مثل <code>onclick=</code>."]);

    const httpLinks = $$('a[href^="http://"]').length;
    if (!httpLinks) rows.push(["pass", "روابط آمنة", "جميع الروابط الخارجية تستخدم HTTPS."]);
    else rows.push(["warn", "روابط غير مشفّرة", httpLinks + " رابطًا يستخدم http:// بدل https://."]);

    const imgNoAlt = $$("img:not([alt])").length;
    if (!imgNoAlt) rows.push(["pass", "وصولية الصور", "كل الصور تحتوي على نص بديل أو لا توجد صور."]);
    else rows.push(["warn", "صور بلا نص بديل", imgNoAlt + " صورة بلا <code>alt</code>."]);

    const bytes = new Blob([html]).size;
    rows.push(["pass", "حجم الصفحة", fmtBytes(bytes) + " من HTML بعد الترتيب والتنسيق الكامل."]);

    if (/<input[^>]+type=["']password["']/i.test(html)) rows.push(["pass", "حقول حساسة", "حقل التوكن من نوع password ولا يظهر على الشاشة."]);

    return rows;
  }

  $("#btnAuditSite").addEventListener("click", async () => {
    const rows = localAudit();
    let url = (siteUrl.value || "").trim();
    let remoteHtml = "";
    auditOut.innerHTML = rows.map(r => auditRow(r[0], r[1], r[2])).join("") +
      '<div class="hint mt8">✓ تم فحص الصفحة الحالية. ' + (url ? "جارٍ فحص الرابط الخارجي…" : "أضف رابطًا خارجيًا لفحصه أيضًا.") + "</div>";

    if (!url) return;
    if (!/^https?:\/\//i.test(url)) url = "https://" + url;
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 12000);
    const t0 = performance.now();
    try {
      const res = await fetch(url, { mode: "cors", cache: "no-store", signal: ctrl.signal });
      const ms = Math.round(performance.now() - t0);
      const text = await res.text();
      clearTimeout(timer);
      const extra = [];
      extra.push(res.ok ? ["pass", "الاستجابة", "الحالة <code>" + res.status + "</code> خلال " + ms + "ms."]
        : ["fail", "خطأ في الاستجابة", "الحالة <code>" + res.status + "</code> — الصفحة غير متاحة."]);
      const ct = res.headers.get("content-type") || "";
      if (/text\/html/i.test(ct)) extra.push(["pass", "نوع المحتوى", "<code>" + esc(ct) + "</code> — صفحة HTML صحيحة."]);
      else extra.push(["warn", "نوع المحتوى غير معتاد", "<code>" + esc(ct || "غير معروف") + "</code>"]);
      if (ms < 800) extra.push(["pass", "سرعة الاستجابة", ms + "ms — سريعة (شبكة حافة جيدة)."]);
      else if (ms < 2500) extra.push(["warn", "سرعة متوسطة", ms + "ms — يمكن تحسينها بالكاش."]);
      else extra.push(["fail", "استجابة بطيئة", ms + "ms — راجع الأداء."]);

      if (/<meta[^>]+viewport/i.test(text)) extra.push(["pass", "متوافق مع الجوال", "الرابط الخارجي يحتوي على meta viewport."]);
      else extra.push(["warn", "غير متوافق مع الجوال", "لم أجد meta viewport في الصفحة الخارجية."]);
      if (/edgeone|tencent|qcloud/i.test(text)) extra.push(["pass", "بصمة EdgeOne", "تم العثور على مؤشر لاستضافة EdgeOne/Tencent في المحتوى."]);
      if (/(__NEXT_DATA__|\/assets\/|cdn)/i.test(text)) extra.push(["pass", "بنية أصول", "تظهر مؤشرات تحميل أصول ساكنة بشكل صحيح."]);
      if (text.length > 200000) extra.push(["warn", "HTML ثقيل", fmtBytes(new Blob([text]).size) + " — فكّر بتقسيم الصفحة."]);
      else extra.push(["pass", "حجم HTML", fmtBytes(new Blob([text]).size) + "."]);

      auditOut.innerHTML = rows.map(r => auditRow(r[0], r[1], r[2])).join("") +
        '<div class="sep"></div><div class="hint" style="margin-bottom:8px">🌐 فحص الرابط الخارجي <span class="mono">' + esc(url) + "</span></div>" +
        extra.map(r => auditRow(r[0], r[1], r[2])).join("");
      toast("تم فحص الموقع والرابط الخارجي", "ok");
    } catch (e) {
      clearTimeout(timer);
      const ms = Math.round(performance.now() - t0);
      const isAbort = e.name === "AbortError";
      auditOut.innerHTML = rows.map(r => auditRow(r[0], r[1], r[2])).join("") +
        '<div class="sep"></div>' +
        auditRow("warn", "تعذّر قراءة الرابط الخارجي",
          (isAbort ? "انتهت المهلة بعد 12 ثانية." : "خطأ شبكة: " + esc(e.message)) +
          " — السبب الأشيع هو منع <b>CORS</b> من الخادم (لا يستطيع المتصفح قراءة صفحات نطاقات أخرى بلا ترويسة سماح)." +
          " افتح الرابط في تبويب جديد للتحقق اليدوي، أو افحصه عبر أدوات مثل Lighthouse.") +
        '<div class="finding pass"><span class="f-ic">i</span><div class="f-body"><div class="f-title">الفحص المحلي للصفحة الحالية مكتمل</div>' +
        '<div class="f-desc">' + rows.filter(r => r[0] === "pass").length + " عنصرًا سليمًا من أصل " + rows.length + " (زمن المحاولة " + ms + "ms).</div></div></div>";
      toast("تعذّر فحص الرابط الخارجي (CORS) — تم الفحص المحلي", "warn", 5000);
    }
  });

  $("#btnAuditTelegram").addEventListener("click", async () => {
    auditOut.innerHTML = '<div class="finding warn"><span class="f-ic">…</span><div class="f-body"><div class="f-title">جارٍ فحص الاتصال بـ Telegram…</div><div class="f-desc">نرسل طلبًا وهميًا بالتوكن 0:0 ونتوقع ردّ 401 من تلغرام.</div></div></div>';
    const t0 = performance.now();
    const r = await tgCall("getMe", "0:0");
    const ms = Math.round(performance.now() - t0);
    let html = "";
    if (r.error) {
      html += auditRow("fail", "لا يمكن الوصول إلى api.telegram.org",
        esc(r.error) + " — قد تكون الشبكة تحجب تلغرام، أو أنك تستخدم شبكة مقيّدة. لن يعمل البوت من هذه الشبكة.");
      html += auditRow("warn", "بديل", "جرّب من شبكة أخرى أو عبر VPN، وإلا سيعمل البوت على سيرفر بعيد بلا مشكلة.");
    } else {
      const ok401 = r.http === 401 && r.data && r.data.ok === false;
      html += auditRow(ok401 ? "pass" : "warn", "الاتصال بتلغرام يعمل",
        "الحالة <code>" + r.http + "</code> خلال " + ms + "ms" +
        (r.data ? " — رسالة تلغرام: <code>" + esc(r.data.description || "") + "</code>" : "") + ".");
      if (ok401) html += auditRow("pass", "دعم CORS", "تلغرام يعيد <code>access-control-allow-origin: *</code>، لذا يستطيع المتصفح التحقق من التوكن مباشرة.");
      html += auditRow(ms < 900 ? "pass" : "warn", "زمن الاستجابة", ms + "ms — " + (ms < 900 ? "ممتاز" : "مرتفع نسبيًا، قد يزيد زمن التحقق") + ".");
      html += auditRow("pass", "الخلاصة", "إن أضفت توكنًا صحيحًا فسيتم التحقق منه فعليًا وإرسال رسائل تجربة.");
    }
    auditOut.innerHTML = html;
    toast(r.error ? "تعذّر الوصول لتلغرام" : "الاتصال بتلغرام سليم", r.error ? "err" : "ok");
  });

  /* ============================ تنزيل حزمة البداية ============================ */
  function buildStarterZip() {
    const entries = [];
    entries.push({
      name: "README.txt",
      data: "EdgeOneHost — حزمة البداية\n" +
        "=========================\n\n" +
        "1) ثبّت المكتبة:  pip install pyTelegramBotAPI\n" +
        "2) احفظ التوكن في متغيّر بيئة:\n" +
        "   Windows:  set BOT_TOKEN=123:ABC\n" +
        "   Linux:    export BOT_TOKEN=123:ABC\n" +
        "3) شغّل:  python echo_bot.py\n" +
        "4) في تلغرام أرسل /start للبوت.\n\n" +
        "تنبيه: لا ترفع ملفًا يحتوي التوكن إلى مستودع عام.\n"
    });
    Object.keys(samples).forEach(k => {
      entries.push({ name: "samples/" + samples[k].name, data: samples[k].code });
    });
    const f = activeFile();
    if (f && f.code.trim()) entries.push({ name: "my_project/" + f.name, data: f.code });
    entries.push({ name: "requirements.txt", data: "pyTelegramBotAPI>=4.15.0\n# aiogram>=3.7.0\n# python-telegram-bot>=21.0\n" });
    const blob = window.makeZip ? window.makeZip(entries) : null;
    if (!blob) { toast("تعذّر إنشاء الحزمة", "err"); return; }
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "edgeonehost-starter.zip";
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 2000);
    toast("تم تنزيل حزمة البداية", "ok");
  }

  const zipModal = $("#zipModal");
  $("#btnDownloadZip").addEventListener("click", () => { zipModal.hidden = false; });
  $("#zipClose").addEventListener("click", () => { zipModal.hidden = true; });
  $("#zipOk").addEventListener("click", () => { zipModal.hidden = true; });
  zipModal.addEventListener("click", e => { if (e.target === zipModal) zipModal.hidden = true; });
  const starterBtn = document.createElement("button");
  starterBtn.className = "btn btn-primary btn-sm";
  starterBtn.textContent = "⤓ تنزيل حزمة البداية الآن";
  starterBtn.addEventListener("click", buildStarterZip);
  $(".m-foot").insertBefore(starterBtn, $("#zipOk"));

  /* ============================ واجهة عامة ============================ */
  const burger = $("#burger"), navLinks = $("#navLinks");
  burger.addEventListener("click", () => navLinks.classList.toggle("open"));
  $$("#navLinks a").forEach(a => a.addEventListener("click", () => navLinks.classList.remove("open")));
  $("#year").textContent = new Date().getFullYear();

  // اختصارات
  document.addEventListener("keydown", e => {
    if ((e.ctrlKey || e.metaKey) && e.key === "Enter" && document.activeElement !== editor) { e.preventDefault(); runBot(); }
    if (e.key === "Escape") zipModal.hidden = true;
  });

  /* ============================ بطاقة الهيرو ============================ */
  const heroCode = $("#heroCode");
  const heroState = $("#heroState");
  function typeHero() {
    if (!heroCode) return;
    const code = samples.simple ? samples.simple.code : "";
    const slice = code.split("\n").slice(0, 22).join("\n");
    let i = 0;
    heroCode.innerHTML = "";
    const chunk = 7;
    const timer = setInterval(() => {
      if (i >= slice.length) {
        clearInterval(timer);
        heroState.textContent = "polling • 0 errors";
        setTimeout(() => {
          heroCode.innerHTML = "";
          heroState.textContent = "starting…";
          i = 0;
          setTimeout(typeHero, 900);
        }, 9000);
        return;
      }
      i = Math.min(slice.length, i + chunk);
      heroCode.innerHTML = highlightPython(slice.slice(0, i)) + '<span style="color:#2ea8ff">▌</span>';
    }, 22);
  }

  /* ============================ التهيئة ============================ */
  function init() {
    // الملفات المحفوظة
    const saved = LS.get(K_FILES, null);
    if (saved && Array.isArray(saved) && saved.length) {
      state.files = saved.map(f => ({ id: f.id || uid(), name: f.name || "bot.py", code: f.code || "", addedAt: f.addedAt || Date.now() }));
    }
    // توكن محفوظ
    const savedToken = LS.get(K_TOKEN, "");
    const savedOwner = LS.get(K_OWNER, "");
    if (savedToken) { tokenInput.value = savedToken; persistToken.checked = true; state.token = savedToken; }
    if (savedOwner) { $("#ownerInput").value = savedOwner; state.owner = savedOwner; }
    persistToken.addEventListener("change", () => {
      if (persistToken.checked && tokenInput.value.trim()) { LS.set(K_TOKEN, tokenInput.value.trim()); toast("سيُحفظ التوكن في هذا الجهاز", "info", 2200); }
      else { LS.del(K_TOKEN); }
    });
    tokenInput.addEventListener("change", () => {
      if (persistToken.checked) LS.set(K_TOKEN, tokenInput.value.trim());
      state.tokenOk = false;
    });
    $("#ownerInput").addEventListener("change", e => { LS.set(K_OWNER, e.target.value.trim()); });

    // ملف افتراضي أول مرة
    if (!state.files.length) {
      if (samples.simple) {
        state.files = [{ id: uid(), name: samples.simple.name, code: samples.simple.code, addedAt: Date.now() }];
      }
    }
    if (state.files.length) setActive(state.files[0].id, { silent: true });
    else resetAnalysis();

    renderFiles();
    runAnalysisAndRender();
    simReset(true);
    logSep("EdgeOneHost Runner");
    log("مرحبًا 👋 ارفع ملف .py أو اختر مثالًا، ثم اضغط «تشغيل».", "l-sys");
    log("التوكن لا يُرسل لأي سيرفر وسيط — التحقق يتم من متصفحك إلى تلغرام مباشرة.", "l-info");

    if (savedToken) {
      log("تم العثور على توكن محفوظ — اضغط «تحقق من التوكن» للتأكد من صلاحيته.", "l-warn");
      tokenHint.innerHTML = "يوجد توكن محفوظ — اضغط «تحقق من التوكن» للتأكد.";
    }

    setStatus("idle", "● جاهز للتشغيل");
    typeHero();
  }

  document.addEventListener("DOMContentLoaded", init);
  if (document.readyState !== "loading") init();
})();

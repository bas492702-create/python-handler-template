/* =====================================================================
   EdgeOneHost — simulator.js
   محرك "محاكاة البوت": يستخرج الأوامر والردود من كود بايثون المرفوع
   ويعيد بناء سلوك البوت داخل واجهة محادثة تشبه تلغرام.
   لا يُنفَّذ كود بايثون فعليًا — يتم استنتاج السلوك نصيًا.
   ===================================================================== */
(function () {
  "use strict";

  /* ------------------------------------------------------------------
     1) أمثلة جاهزة (كود بايثون حقيقي يمكن تنزيله وتشغيله فعليًا)
     ------------------------------------------------------------------ */
  const samples = {
    simple: {
      name: "echo_bot.py",
      label: "pyTelegramBotAPI",
      code: `"""
echo_bot.py — مثال بسيط لبوت تلغرام باستخدام pyTelegramBotAPI
التشغيل:  pip install pyTelegramBotAPI  ثم  python echo_bot.py
"""
import os
import telebot
from datetime import datetime

# ✅ الأفضل: التوكن من متغيّر بيئة وليس مكتوبًا داخل الكود
BOT_TOKEN = os.environ.get("BOT_TOKEN", "")

bot = telebot.TeleBot(BOT_TOKEN)


@bot.message_handler(commands=["start"])
def send_welcome(message):
    name = message.from_user.first_name or "صديقي"
    bot.reply_to(message, "أهلًا بك يا " + name + "! أنا بوت تجريبي يعمل على EdgeOneHost.")


@bot.message_handler(commands=["help"])
def send_help(message):
    bot.reply_to(message, "الأوامر المتاحة: /start للترحيب، /help لهذه القائمة، /time لمعرفة الوقت، أو أرسل أي نص وسأعيده لك.")


@bot.message_handler(commands=["time"])
def send_time(message):
    bot.reply_to(message, "الوقت الآن: " + datetime.now().strftime("%Y-%m-%d %H:%M:%S"))


@bot.message_handler(func=lambda message: True)
def echo_all(message):
    bot.reply_to(message, "وصلتني رسالتك: " + message.text)


if __name__ == "__main__":
    print("البوت يعمل الآن... اضغط Ctrl+C للإيقاف")
    bot.infinity_polling()
`
    },

    aiogram: {
      name: "aiogram_bot.py",
      label: "aiogram 3.x",
      code: `"""
aiogram_bot.py — مثال باستخدام aiogram 3.x (غير متزامن)
التشغيل:  pip install aiogram  ثم  python aiogram_bot.py
"""
import asyncio
import logging
import os

from aiogram import Bot, Dispatcher, F
from aiogram.filters import Command, CommandStart
from aiogram.types import Message

logging.basicConfig(level=logging.INFO)

BOT_TOKEN = os.environ.get("BOT_TOKEN", "")
if not BOT_TOKEN:
    raise SystemExit("ضع التوكن في متغيّر البيئة BOT_TOKEN")

bot = Bot(token=BOT_TOKEN)
dp = Dispatcher()


@dp.message(CommandStart())
async def cmd_start(message: Message):
    await message.answer("أهلًا بك في بوت aiogram! اكتب /help لعرض قائمة الأوامر.")


@dp.message(Command("help"))
async def cmd_help(message: Message):
    await message.answer("الأوامر: /start للترحيب، /help للقائمة، /info لمعلومات التشغيل، وأي نص آخر سأعيده لك.")


@dp.message(Command("info"))
async def cmd_info(message: Message):
    await message.answer("الإصدار: aiogram 3.x، لغة Python 3.11، يعمل عبر polling أو webhook.")


@dp.message(F.text)
async def echo(message: Message):
    await message.answer("صدى: " + message.text)


async def main():
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())
`
    },

    broken: {
      name: "broken_bot.py",
      label: "فيه أخطاء مقصودة",
      code: `# broken_bot.py — ملف يحتوي أخطاء مقصودة لتجربة محرّك الفحص
import telebot

# ❌ التوكن مكتوب مباشرة داخل الكود (خطر أمني)
BOT_TOKEN = "123456789:AAFakeTokenDoNotUseThisExampleAtAll"

bot = telebot.TeleBot(BOT_TOKEN)


@bot.message_handler(commands=['start'])
def start(message)
    bot.reply_to(message, "أهلًا بك!")   # ❌ ناقص النقطتان الرأسيتان


while True:
    pass   # ❌ حلقة لا نهائية تستهلك المعالج

bot.polling(none_stop=True)
`
    }
  };

  /* ------------------------------------------------------------------
     2) أدوات نصية
     ------------------------------------------------------------------ */
  const RE_STR = /(["'])((?:\\.|(?!\1).)*)\1/g;

  function stringsIn(text) {
    const out = [];
    let m;
    RE_STR.lastIndex = 0;
    while ((m = RE_STR.exec(text)) !== null) {
      // تجاهل النصوص القصيرة جدًا أو التي تبدو معرّفات
      out.push(m[2]);
    }
    return out;
  }

  function pickReplyText(callArgs) {
    const list = stringsIn(callArgs).filter(s => s.length > 1 && !/^[A-Za-z_]+$/.test(s));
    if (!list.length) return null;
    // أطول نص هو غالبًا نص الرد
    return list.sort((a, b) => b.length - a.length)[0];
  }

  function interpolate(text, ctx) {
    if (!text) return text;
    let out = text;
    const now = ctx.now;
    out = out.replace(/\{time:([^}]*)\}/g, function (all, fmt) { return strftimeJS(fmt, new Date()); });
    // أنماط f-string الشائعة
    out = out.replace(/\{datetime\.now\(\)[^}]*\}/g, now.full);
    out = out.replace(/\{time\.strftime\([^}]*\)\}/g, now.time);
    out = out.replace(/\{date\.today\(\)[^}]*\}/g, now.date);
    const map = {
      name: ctx.name || "صديقي",
      first_name: ctx.name || "صديقي",
      user: ctx.name || "صديقي",
      username: ctx.name || "صديقي",
      time: now.time,
      date: now.date,
      dt: now.full,
      year: String(now.year),
      chat_id: "100200300",
      id: "100200300",
      count: String(Math.floor(Math.random() * 900) + 100),
      counter: String(Math.floor(Math.random() * 90) + 10),
      text: ctx.text || "",
      message: ctx.text || ""
    };
    out = out.replace(/\{\{?\s*([a-zA-Z_][a-zA-Z0-9_]*)\s*\}?\}/g, (all, key) =>
      Object.prototype.hasOwnProperty.call(map, key) ? map[key] : all
    );
    return out;
  }

  /* ------------------------------------------------------------------
     3) تحليل الكود → ملف تعريف البوت (bot profile)
     ------------------------------------------------------------------ */
  function detectFramework(code) {
    if (/from\s+aiogram|import\s+aiogram|Dispatcher\s*\(/.test(code))
      return { id: "aiogram", title: "aiogram 3.x", badge: "aiogram" };
    if (/from\s+telegram\.ext|import\s+telegram\b|ApplicationBuilder|Updater\(/.test(code))
      return { id: "ptb", title: "python-telegram-bot", badge: "PTB" };
    if (/import\s+telebot|pyTelegramBotAPI|TeleBot\(/.test(code))
      return { id: "telebot", title: "pyTelegramBotAPI (telebot)", badge: "telebot" };
    if (/(?:requests|aiohttp|httpx).*(?:api\.telegram\.org|getUpdates)/.test(code))
      return { id: "raw", title: "Telegram Bot API مباشرة", badge: "raw API" };
    return { id: "none", title: "غير محدّد", badge: "—" };
  }

  const TOKEN_LITERAL = /\b\d{8,10}:[A-Za-z0-9_-]{30,}\b/;
  const TOKEN_VAR = /(BOT_TOKEN|TELEGRAM_TOKEN|API_TOKEN|TOKEN)\s*=\s*os\.environ|getenv\(\s*["'](?:BOT_TOKEN|TELEGRAM_TOKEN|TOKEN)["']/;

  function splitHandlerBlocks(code) {
    const lines = code.split(/\r?\n/);
    const blocks = [];
    const deco = /^\s*@(bot|dp|router|app|dispatcher)\.(message_handler|handler|message|callback_query_handler)\s*\(/;
    for (let i = 0; i < lines.length; i++) {
      if (!deco.test(lines[i])) continue;
      let j = i;
      let body = "";
      while (j < lines.length) {
        body += lines[j] + "\n";
        j++;
        if (j < lines.length && /^\s*@(bot|dp|router|app|dispatcher)\./.test(lines[j])) break;
      }
      blocks.push({ header: lines[i].trim(), body: body });
      i = j - 1;
    }
    return blocks;
  }

  function commandsFromHeader(header) {
    const out = [];
    // commands=["a","b"]
    const m = header.match(/commands\s*=\s*\[([^\]]*)\]/);
    if (m) {
      stringsIn(m[1]).forEach(s => out.push(s.replace(/^\//, "").toLowerCase()));
    }
    // CommandStart()
    if (/CommandStart\s*\(/.test(header) && !out.includes("start")) out.push("start");
    // Command("help")
    const c = header.match(/Command\s*\(\s*["']([^"']+)["']/);
    if (c) out.push(c[1].replace(/^\//, "").toLowerCase());
    return out;
  }

  /* ------------------------------------------------------------------
     استخراج نص الرد من تعبير بايثون: نبني "قالبًا" يجمع النصوص
     ويحوّل المتغيّرات المعروفة إلى عناصر نائبة {name} / {text} / {time:...}
     ------------------------------------------------------------------ */

  // تحويل تنسيق strftime في بايثون إلى نص فعلي
  function strftimeJS(fmt, d) {
    const p = n => String(n).padStart(2, "0");
    const days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];
    const months = ["January", "February", "March", "April", "May", "June", "July",
      "August", "September", "October", "November", "December"];
    const map = {
      Y: () => String(d.getFullYear()), y: () => p(d.getFullYear() % 100),
      m: () => p(d.getMonth() + 1), d: () => p(d.getDate()),
      H: () => p(d.getHours()), I: () => p((d.getHours() % 12) || 12),
      M: () => p(d.getMinutes()), S: () => p(d.getSeconds()),
      p: () => (d.getHours() < 12 ? "AM" : "PM"),
      A: () => days[d.getDay() - 1] || "", a: () => (days[d.getDay() - 1] || "").slice(0, 3),
      B: () => months[d.getMonth()], b: () => months[d.getMonth()].slice(0, 3),
      j: () => String(Math.ceil((d - new Date(d.getFullYear(), 0, 0)) / 86400000)).padStart(3, "0"),
      f: () => String(d.getMilliseconds() * 1000).padStart(6, "0"),
      "%": () => "%", n: () => "\n", t: () => "\t"
    };
    return String(fmt).replace(/%([YymdHIMSpAabjf%nt])/g, (all, k) => (map[k] ? map[k]() : all));
  }

  // إيجاد نهاية استدعاء دالة بدءًا من موضع القوس المفتوح (يتجاهل النصوص والأقواس الداخلية)
  function matchParen(src, openIdx) {
    let depth = 0, i = openIdx, quote = null;
    while (i < src.length) {
      const c = src[i];
      if (quote) {
        if (c === "\\") { i += 2; continue; }
        if (c === quote) quote = null;
        i++; continue;
      }
      if (c === '"' || c === "'") {
        const tri = src.substr(i, 3);
        if (tri === '"""' || tri === "'''") { const j = src.indexOf(tri, i + 3); i = j === -1 ? src.length : j + 3; continue; }
        quote = c; i++; continue;
      }
      if (c === "#") { const j = src.indexOf("\n", i); i = j === -1 ? src.length : j; continue; }
      if (c === "(" || c === "[" || c === "{") depth++;
      else if (c === ")" || c === "]" || c === "}") {
        depth--;
        if (depth === 0) return i;
      }
      i++;
    }
    return -1;
  }

  function splitArgs(argSrc) {
    const out = [];
    let depth = 0, cur = "", quote = null;
    for (let i = 0; i < argSrc.length; i++) {
      const c = argSrc[i];
      if (quote) {
        cur += c;
        if (c === "\\") { cur += argSrc[++i] || ""; continue; }
        if (c === quote) quote = null;
        continue;
      }
      if (c === '"' || c === "'") { quote = c; cur += c; continue; }
      if (c === "(" || c === "[" || c === "{") depth++;
      if (c === ")" || c === "]" || c === "}") depth--;
      if (c === "," && depth === 0) { out.push(cur.trim()); cur = ""; continue; }
      cur += c;
    }
    if (cur.trim()) out.push(cur.trim());
    return out;
  }

  function exprToTemplate(expr) {
    if (!expr) return null;
    let e = " " + expr + " ";

    // تحويل strftime(...) إلى عنصر نائب زمني
    e = e.replace(/(?:datetime\.datetime\.(?:now|utcnow)\(\)|datetime\.(?:now|utcnow)\(\)|time\.time\(\))?\.?strftime\(\s*["']([^"']*)["']\s*\)/g,
      (m, fmt) => "{time:" + fmt + "}");
    e = e.replace(/datetime\.(?:datetime\.)?(?:now|utcnow)\(\)|datetime\.now\(\)|time\.time\(\)/g, "{time:%Y-%m-%d %H:%M:%S}");

    // إزالة أغلفة شائعة
    e = e.replace(/html\.escape\(/g, "(");
    e = e.replace(/str\(/g, "(");
    e = e.replace(/\.format\([^()]*\)/g, "");

    // متغيّرات معروفة → عناصر نائبة
    e = e.replace(/\(\s*message\.from_user\.first_name\s*or\s*["'][^"']*["']\s*\)/g, "{name}");
    e = e.replace(/message\.from_user\.(?:first_name|username|full_name)/g, "{name}");
    e = e.replace(/\b(?:message|msg|m|event)\.text\b/g, "{text}");
    e = e.replace(/\b(?:message|msg|m|event)\.(?:from_user|from|user)\.(?:first_name|username|full_name)/g, "{name}");
    e = e.replace(/\b(?:message|msg|m|event)\.chat\.id\b/g, "{chat_id}");
    e = e.replace(/message\.chat\.id/g, "{chat_id}");
    e = e.replace(/message\.message_id/g, "{message_id}");
    e = e.replace(/user\.(?:first_name|username|full_name)/g, "{name}");
    e = e.replace(/\bname\b/g, "{name}");
    e = e.replace(/\bcount\b|\bcounter\b/g, "{count}");

    // جمع النصوص والعناصر النائبة بالترتيب
    let out = "", i = 0;
    const keep = /^\{(?:name|text|chat_id|message_id|count|time:[^}]*)\}/;
    while (i < e.length) {
      const c = e[i];
      if (c === '"' || c === "'") {
        const tri = e.substr(i, 3);
        if (tri === '"""' || tri === "'''") {
          const j = e.indexOf(tri, i + 3);
          out += e.slice(i + 3, j === -1 ? e.length : j);
          i = j === -1 ? e.length : j + 3; continue;
        }
        let j = i + 1, buf = "";
        while (j < e.length) {
          if (e[j] === "\\") {
            const nx = e[j + 1];
            buf += nx === "n" ? "\n" : nx === "t" ? "\t" : nx;
            j += 2; continue;
          }
          if (e[j] === c) { j++; break; }
          if (e[j] === "\n") break;
          buf += e[j]; j++;
        }
        out += buf; i = j; continue;
      }
      if (c === "{") {
        const m = e.slice(i).match(keep);
        if (m) { out += m[0]; i += m[0].length; continue; }
        i++; continue;
      }
      i++;
    }
    out = out.replace(/\{\{([^{}]*)\}\}/g, "{$1}");
    out = out.replace(/[ \t]{2,}/g, " ").trim();
    return out || null;
  }

  const REPLY_CALLS = ["reply_to", "answer", "reply_text", "send_message", "edit_text", "edit_message_text", "respond"];

  function replyFromBlock(body) {
    // ابحث عن أول استدعاء إرسال رسالة داخل البلوك
    for (const name of REPLY_CALLS) {
      const re = new RegExp("(?:\\.|\\b)" + name + "\\s*\\(", "g");
      const m = re.exec(body);
      if (!m) continue;
      const open = body.indexOf("(", m.index + m[0].length - 1);
      const close = matchParen(body, open);
      if (close === -1) continue;
      const argsSrc = body.slice(open + 1, close);
      const args = splitArgs(argsSrc);
      let best = null;
      args.forEach((arg, idx) => {
        if (idx === 0 && /^(message|msg|chat_id|update|bot)\b/.test(arg.trim())) return;
        if (/^(reply_markup|parse_mode|reply_to_message_id|disable_web_page_preview)\s*=/.test(arg.trim())) return;
        const tpl = exprToTemplate(arg);
        if (!tpl) return;
        const score = (tpl.match(/[\u0600-\u06FF]/g) || []).length + tpl.length;
        if (!best || score > best.score) best = { tpl: tpl, score: score };
      });
      if (best) return best.tpl;
    }
    // احتياطي: أطول نص داخل البلوك
    const strs = stringsIn(body).filter(x => x.length > 8);
    return strs.length ? strs.sort((a, b) => b.length - a.length)[0] : null;
  }

  // كتلة دالة بايثون بالاسم (بدون الديكوريتر) — تُستخدم مع CommandHandler/MessageHandler
  function functionBody(src, name) {
    const re = new RegExp("(?:async\\s+)?def\\s+" + name + "\\s*\\(");
    const m = re.exec(src);
    if (!m) return null;
    const lineStart = src.lastIndexOf("\n", m.index) + 1;
    const indent = (src.slice(lineStart, m.index).match(/^\s*/) || [""])[0].length;
    const lines = src.slice(lineStart).split("\n");
    const out = [lines[0]];
    for (let i = 1; i < lines.length; i++) {
      const l = lines[i];
      if (!l.trim()) { out.push(l); continue; }
      const ind = (l.match(/^\s*/) || [""])[0].length;
      if (ind <= indent) break;
      out.push(l);
    }
    return out.join("\n");
  }

  // معالجات python-telegram-bot: CommandHandler("start", fn) و MessageHandler(filters.TEXT, fn)
  function ptbHandlers(src, handlers, commands) {
    const cmdRe = /CommandHandler\s*\(\s*["']([^"']+)["']\s*,\s*([A-Za-z_][A-Za-z0-9_]*)/g;
    let m;
    while ((m = cmdRe.exec(src)) !== null) {
      const cmd = m[1].replace(/^\//, "").toLowerCase();
      const body = functionBody(src, m[2]) || "";
      const reply = replyFromBlock(body);
      if (!handlers[cmd]) handlers[cmd] = reply || null;
      if (commands.indexOf(cmd) === -1) commands.push(cmd);
    }
    const anyRe = /MessageHandler\s*\(\s*([^,]+),\s*([A-Za-z_][A-Za-z0-9_]*)/g;
    while ((m = anyRe.exec(src)) !== null) {
      if (!/TEXT|PHOTO|ALL|everything/i.test(m[1])) continue;
      if (/~filters\.COMMAND|~filters\.Commands/i.test(m[1])) {
        const body = functionBody(src, m[2]) || "";
        if (!handlers.__any__) handlers.__any__ = replyFromBlock(body) || null;
      }
    }
  }

  function profile(code) {
    const src = String(code || "");
    const framework = detectFramework(src);
    const blocks = splitHandlerBlocks(src);
    const handlers = {};
    const commandsList = [];

    blocks.forEach(b => {
      const cmds = commandsFromHeader(b.header);
      const reply = replyFromBlock(b.body);
      const anyText = /func\s*=\s*lambda|F\.text|filters\.TEXT|ContentType\.TEXT|filters\.text/.test(b.header + b.body);
      if (cmds.length) {
        cmds.forEach(c => {
          if (!handlers[c]) handlers[c] = reply || null;
          if (!commandsList.includes(c)) commandsList.push(c);
        });
      } else if (anyText) {
        handlers.__any__ = reply || null;
      }
    });

    // معالجات python-telegram-bot (CommandHandler/MessageHandler)
    if (/\.add_handler\(/.test(src) || /CommandHandler\s*\(/.test(src)) {
      ptbHandlers(src, handlers, commandsList);
    }

    // استخراج إضافي: أي قائمة أوامر في الكود
    const all = src.match(/commands\s*=\s*\[([^\]]*)\]/g) || [];
    all.forEach(chunk => stringsIn(chunk).forEach(s => {
      const c = s.replace(/^\//, "").toLowerCase();
      if (c && !commandsList.includes(c)) commandsList.push(c);
    }));
    if (/CommandStart\s*\(/.test(src) && !commandsList.includes("start")) commandsList.unshift("start");
    const cm = src.match(/Command\s*\(\s*["']([^"']+)["']/g) || [];
    cm.forEach(chunk => {
      const s = chunk.match(/["']([^"']+)["']/);
      if (s) {
        const c = s[1].replace(/^\//, "").toLowerCase();
        if (!commandsList.includes(c)) commandsList.push(c);
      }
    });

    const echo = /(reply_to|send_message|answer|reply_text)\s*\([^)]*message\.text/.test(src) ||
      /message\.text\s*\+\s*["']/.test(src) ||
      /["']\s*\+\s*message\.text/.test(src) ||
      /echo/i.test(src);
    const echoReply = handlers.__any__ || (echo ? "وصلتني رسالتك: " : null);

    return {
      framework,
      blocks,
      handlers,
      commands: commandsList,
      echo,
      echoReply,
      tokenLiteral: (src.match(TOKEN_LITERAL) || [])[0] || null,
      tokenFromEnv: TOKEN_VAR.test(src),
      imports: Array.from(new Set((src.match(/^\s*(?:from|import)\s+([A-Za-z0-9_.]+)/gm) || [])
        .map(s => s.replace(/^\s*(?:from|import)\s+/, "").trim()))),
      usesPolling: /(infinity_polling|start_polling|bot\.polling|polling\s*\()/.test(src),
      usesWebhook: /(set_webhook|setWebhook|webhook|aiohttp\.web|FastAPI|Flask)/i.test(src),
      hasMain: /if\s+__name__\s*==\s*["']__main__["']/.test(src),
      lines: src ? src.split(/\r?\n/).length : 0,
      chars: src.length
    };
  }

  /* ------------------------------------------------------------------
     4) توليد الرد
     ------------------------------------------------------------------ */
  function nowCtx() {
    const d = new Date();
    const p = n => String(n).padStart(2, "0");
    return {
      time: p(d.getHours()) + ":" + p(d.getMinutes()) + ":" + p(d.getSeconds()),
      date: d.getFullYear() + "-" + p(d.getMonth() + 1) + "-" + p(d.getDate()),
      full: d.getFullYear() + "-" + p(d.getMonth() + 1) + "-" + p(d.getDate()) + " " +
        p(d.getHours()) + ":" + p(d.getMinutes()) + ":" + p(d.getSeconds()),
      year: d.getFullYear()
    };
  }

  function buildReply(prof, text, ctx) {
    const clean = String(text || "").trim();
    const c = Object.assign({ now: nowCtx(), text: clean, name: (ctx && ctx.name) || "صديقي" }, ctx || {});
    if (!clean) return { type: "sys", text: "رسالة فارغة" };

    if (clean.startsWith("/")) {
      const cmdFull = clean.slice(1).split(/\s+/)[0].toLowerCase();
      const cmd = cmdFull.split("@")[0];
      if (Object.prototype.hasOwnProperty.call(prof.handlers, cmd) && prof.handlers[cmd]) {
        return { type: "bot", text: interpolate(prof.handlers[cmd], Object.assign({}, c, { name: (ctx && ctx.name) || "صديقي" })) };
      }
      if (prof.commands.includes(cmd)) {
        return { type: "bot", text: "✅ الأمر /" + cmd + " موجود في الكود، لكن لم أستطع استخراج نص الرد تلقائيًا (قد يكون نصًا ديناميكيًا أو مُرسلًا من دالة مساعدة)." };
      }
      if (prof.echo || prof.handlers.__any__) {
        return { type: "bot", text: "🤔 لا يوجد معالج للأمر /" + cmd + " في هذا الملف. لكن يوجد معالج عام، لذا سأردّ: " + interpolate(prof.echoReply || "…", c) };
      }
      return { type: "bot", text: "🤔 لا يوجد معالج للأمر /" + cmd + " في الكود المرفوع. الأوامر المتاحة: " + (prof.commands.length ? prof.commands.map(x => "/" + x).join(" · ") : "لا يوجد") };
    }

    if (prof.echo) {
      return { type: "bot", text: interpolate(prof.echoReply || "وصلتني رسالتك: " + clean, c) };
    }
    if (prof.handlers.__any__) {
      return { type: "bot", text: interpolate(prof.handlers.__any__, c) };
    }
    if (prof.commands.length) {
      return { type: "bot", text: "📋 أنا بوت يعمل بالأوامر فقط. جرّب: " + prof.commands.map(x => "/" + x).join(" · ") };
    }
    return { type: "bot", text: "لم أجد معالجات برسائل في الكود، لذلك لا أعرف كيف أردّ على هذه الرسالة." };
  }

  function greeting(prof, name) {
    if (prof.handlers.start) {
      return interpolate(prof.handlers.start, { now: nowCtx(), name: name || "صديقي", text: "/start" });
    }
    if (prof.framework.id === "none") {
      return "لم يتم اكتشاف مكتبة بوت في هذا الملف. ارفع ملفًا يستخدم telebot أو aiogram أو python-telegram-bot.";
    }
    return "أهلًا بك! 👋 أنا " + prof.framework.title + ". جرّب /" + (prof.commands[0] || "start") + " أو أرسل رسالة.";
  }

  /* ------------------------------------------------------------------
     5) واجهة عامة
     ------------------------------------------------------------------ */
  window.BotSim = {
    samples,
    profile,
    buildReply,
    greeting,
    interpolate,
    stringsIn,
    nowCtx,
    strftimeJS,
    exprToTemplate,
    replyFromBlock
  };
})();

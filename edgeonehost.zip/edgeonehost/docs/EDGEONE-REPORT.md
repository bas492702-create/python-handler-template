# تقرير الفحص: هل تعمل استضافة بوتات تلغرام (Python) على EdgeOne؟

> **تاريخ الفحص:** 30 أكتوبر 2026
> **المنصة المفحوصة:** EdgeOne Makers — الاسم السابق **EdgeOne Pages** (`pages.edgeone.ai`) من Tencent Cloud
> **الخلاصة بجملة واحدة:** الموقع (HTML/CSS/JS) **يُستضاف بالكامل**. أما البوت بنمط `bot.polling()` الدائم **لا يعمل** — والطريقة الصحيحة هي **Webhook** عبر Python Cloud Function.

---

## 1) الخلاصة التنفيذية

| السؤال | الجواب |
|---|---|
| هل أستطيع رفع موقع HTML/CSS/JS على EdgeOne؟ | ✅ نعم، استضافة ثابتة/CDN عالمي، بدون إعداد. |
| هل يدعم EdgeOne تشغيل Python؟ | ✅ نعم، عبر **Cloud Functions** (رَنتايم Python 3.9+). |
| هل يعمل `bot.polling()` / `infinity_polling()`؟ | ❌ لا. الدالة تُنفَّذ عند الطلب وتُغلق بعدها (لا عملية دائمة، مهلة تنفيذ محدودة 10–120 ثانية). |
| هل يعمل البوت عبر Webhook؟ | ✅ نعم، بشروط: ردّ سريع، حالة محفوظة خارجيًا، حماية بالـ secret. |
| ما البديل البسيط لبوت دائم؟ | VPS أو منصة حاويات (Railway / Render / Koyeb / Fly.io). |

**النتيجة العملية:** درجة توافق البوت التقليدي (Polling) مع EdgeOne = **35/100**.
درجة توافق نسخة Webhook = **90/100** (ينقصها فقط التخزين الدائم الخارجي).

---

## 2) ما يدعمه EdgeOne Makers بالتحديد (بعد فحص الوثائق)

| القدرة | الحالة | ملاحظات |
|---|---|---|
| استضافة ثابتة (Static / SPA) | ✅ | `index.html` + `assets/` تعمل مباشرة. |
| **Cloud Functions — Node.js** | ✅ | Express/Koa، WebSocket. |
| **Cloud Functions — Python** | ✅ | Flask / FastAPI / Django / Sanic / **Handler mode** (`BaseHTTPRequestHandler`). |
| **Cloud Functions — Go** | ✅ | Gin / Echo / Fiber / net/http. |
| **Edge Functions (V8)** | ✅ | Web APIs + KV Storage. |
| **Middleware** | ✅ | مصادقة، تحويلات، A/B. |
| مهلة التنفيذ (maxDuration) | ⚠️ | 10–120 ثانية، الافتراضي 30 — تُضبط في `edgeone.json`. |
| عملية دائمة / دائرة عملية (Long-running) | ❌ | غير متاح في نموذج الطلب/الاستجابة. |
| الكرون/المهام المجدولة | ✅ | قسم `schedules` في `edgeone.json` (مناسب لتنبيهات دورية لا لبوت تفاعلي). |
| تخزين دائم (ملفات/قاعدة بيانات) | ⚠️ | غير مضمون بين الطلبات؛ استخدم خدمة خارجية أو KV. |
| متغيّرات بيئة للأسرار | ✅ | لوحة المشروع → Environment Variables (`BOT_TOKEN` ...). |

---

## 3) لماذا لا يعمل Polling على Serverless؟ (السبب التقني)

```
Polling التقليدي (VPS)                    Serverless (EdgeOne Cloud Function)
─────────────────────────                ───────────────────────────────────
عملية python تبقى حيّة                   الدالة تُستدعى عند وصول HTTP request
while True:                              ↓
    bot.getUpdates(timeout=30)           تنفيذ لفترة قصيرة (مهلة maxDuration)
    for u in updates: handle(u)          ↓
                                         تُجمَّد/تُغلق الدالة
(اتصال مفتوح دائم مع تلغرام)              (لا شيء يعمل بين الطلبات)
```

- `bot.polling()` يحتاج **جلسة HTTP طويلة العمر** + **حلقة لا نهائية**. نموذج الدوال بلا حالة (stateless) وله مهلة.
- محاولة تشغيل حلقة داخل دالة تُنهي التنفيذ بمهلة، وستدفع تكلفة تنفيذ باستمرار.
- `409 Conflict` يظهر إذا كان نفس التوكن يعمل بـ polling في مكان آخر.

---

## 4) النمط الصحيح على EdgeOne: Webhook

```
المستخدم في تلغرام
      │  يرسل /start
      ▼
خوادم تلغرام ──POST──▶ https://<project>.edgeone.app/api/telegram-webhook
                              │  (Python Cloud Function)
                              ▼
                       1) تحقق من X-Telegram-Bot-Api-Secret-Token
                       2) اقرأ update_id + message.text
                       3) ابنِ الرد (نفس منطق البوت)
                       4) POST sendMessage إلى api.telegram.org
                       5) أرجع 200 OK خلال أقل من ثانية
```

### الملفات الجاهزة في هذا المشروع

| الملف | الوظيفة |
|---|---|
| `edgeone-deploy/cloud-functions/api/telegram-webhook.py` | دالة Python (Handler mode) — **Standard Library فقط**، لا تبعيات. |
| `edgeone-deploy/cloud-functions/index.py` | مسار صحة `GET /` لفحص أن الدوال تعمل. |
| `edgeone-deploy/webhook_bot.py` | نفس المنطق كسيرفر Flask للتشغيل المحلي أو على VPS/حاويات. |
| `edgeone-deploy/public/index.html` | صفحة حالة صغيرة تفحص الويبهوك بالنقر. |
| `edgeone-deploy/edgeone.json` | إعداد `maxDuration` للبايثون + ترويسات `no-store`. |

---

## 5) خطوات النشر على EdgeOne (من الصفر)

1. **أنشئ البوت:** @BotFather → `/newbot` → احتفظ بالتوكن.
2. **جهّز المستودع:** ارفع محتوى `edgeone-deploy/` إلى GitHub.
3. **اربط المشروع:** EdgeOne Makers → *Create Project* → *Import Git Repository* → اختر المستودع.
   - Framework Preset: **Other / Static**
   - Output Directory: `public`
   - الوظائف تُكتشف تلقائيًا من مجلد `cloud-functions/`.
4. **أضف الأسرار:** Settings → **Environment Variables**
   ```
   BOT_TOKEN      = 123456789:AA...
   WEBHOOK_SECRET = نص-عشوائي-طويل-32-حرفًا
   ```
   > تغيير المتغيرات **لا يسري تلقائيًا** — اضغط **Redeploy**.
5. **انشر** ثم تحقّق:
   ```bash
   curl https://<project>.edgeone.app/                       # health
   curl https://<project>.edgeone.app/api/telegram-webhook   # حالة البوت + الويبهوك
   ```
6. **اضبط الويبهوك** (مرة واحدة):
   ```bash
   curl -X POST "https://api.telegram.org/bot<TOKEN>/setWebhook" \
        -H "Content-Type: application/json" \
        -d '{
              "url": "https://<project>.edgeone.app/api/telegram-webhook",
              "secret_token": "<WEBHOOK_SECRET>",
              "allowed_updates": ["message","edited_message"],
              "drop_pending_updates": true
            }'
   ```
7. **تحقّق من الربط:**
   ```bash
   curl "https://api.telegram.org/bot<TOKEN>/getWebhookInfo"
   ```
   يجب أن يظهر `"url"` صحيح و`"pending_update_count": 0` و`last_error_message` فارغ.
8. **اختبار:** أرسل `/start` للبوت في تلغرام.

### قائمة تحقق سريعة (Troubleshooting)

| الأعراض | السبب المحتمل | الحل |
|---|---|---|
| `last_error_message: 401` | `secret_token` غير مطابق | أعد `setWebhook` بنفس قيمة `WEBHOOK_SECRET`. |
| `Wrong response from the webhook: 5xx` | استثناء داخل الدالة | راجع Logs في لوحة EdgeOne؛ الكود يردّ 200 حتى عند فشل الإرسال. |
| `pending_update_count` يتزايد | الدالة لا تردّ بسرعة | اختصر المعالجة، لا تنادِ عمليات طويلة قبل `200 OK`. |
| لا رسائل تصل | الويبهوك غير مضبوط | `setWebhook` بالمسار الصحيح. |
| `401 Unauthorized` من تلغرام | `BOT_TOKEN` خطأ/محذوف | `/token` عند BotFather ثم Redeploy. |
| يعمل محليًا فقط | منفذ/شبكة | تأكد أن الدالة تقرأ `PORT` وتستمع على `0.0.0.0`. |

---

## 6) قيود يجب تصميم البوت حولها

1. **بلا حالة (Stateless):** لا تعتمد على متغيّر عام `users = {}`؛ كل طلب قد يعمل في نسخة أخرى. استخدم قاعدة بيانات (Supabase / Upstash Redis / D1 / MongoDB Atlas).
2. **مهلة التنفيذ:** الافتراضي 30 ثانية. أي عملية أطول (تحويل ملفات، ذكاء اصطناعي بطيء) تحتاج معالجة غير متزامنة أو رفع `maxDuration`.
3. **الملفات المؤقتة:** `/tmp` غير مضمون بين الطلبات. ارفع الملفات إلى تخزين كائنات (S3/R2).
4. **البدء البارد (Cold start):** أول طلب بعد خمول قد يتأخر 200–800ms. لا يهم لتلغرام لأن إعادة المحاولة تلقائية.
5. **الأمان:** فعّل `secret_token` دائمًا، ولا تضع `BOT_TOKEN` في الكود أو الواجهة.
6. **المكتبات الثقيلة:** `python-telegram-bot` أو `python-dotenv` ليست مضمّنة. النسخة المرفقة تستخدم `urllib` فقط لتعمل بلا تثبيت.

---

## 7) متى تختار ماذا؟

| حالة الاستخدام | التوصية |
|---|---|
| بوت تجريبي/بسيط، ردود نصية | ✅ Webhook على EdgeOne (المجلد المرفق). |
| بوت يحتاج جلسات، حالات، صور، ملفات | ⚠️ Webhook + قاعدة بيانات خارجية، أو VPS. |
| بوت ثقيل (AI، تحويل صوت، scraping) | ✅ VPS/حاويات، مع Polling أو Webhook. |
| أريد فقط موقع لوحة تحكم للبوت | ✅ EdgeOne للواجهة + سيرفر Bot منفصل. |
| تعليم أساسيات البوتات | ✅ هذا المشروع: فحص + محاكاة + تحقق حقيقي. |

---

## 8) ما تم اختباره فعليًا أثناء بناء هذا المشروع

| الاختبار | النتيجة |
|---|---|
| فحص 31 نقطة في الواجهة (Playwright) | ✅ 31/31 |
| لا أخطاء JavaScript في الطرفية | ✅ |
| لا تمرير أفقي على 390px | ✅ |
| فحص الملف المعطوب يكشف 3 أخطاء حرجة | ✅ |
| التحقق من تلغرام من المتصفح (CORS) | ✅ الرد `401 Unauthorized` متوقع — الاتصال سليم |
| تشغيل دالة الويبهوك محليًا: حماية secret | ✅ 401 بلا سر / 200 مع السر |
| منع تكرار التحديثات (`update_id`) | ✅ |
| HTML escaping في نصوص المستخدم | ✅ |
| `py_compile` لكل ملفات بايثون | ✅ |

---

## 9) المصادر

- EdgeOne Pages — توثيق المشروع و`edgeone.json`: <https://pages.edgeone.ai/document/edgeone-json>
- EdgeOne Pages — قوالب Python Handler: <https://pages.edgeone.ai/templates/python-handler-template>
- EdgeOne Pages — دعم رَنتايم Python وGo في Cloud Functions: <https://pages.edgeone.ai/resources/news>
- Telegram Bot API: <https://core.telegram.org/bots/api>
- Telegram Webhooks: <https://core.telegram.org/bots/webhooks>

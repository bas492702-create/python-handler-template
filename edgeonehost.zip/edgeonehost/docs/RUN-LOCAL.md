# تشغيل بوت بايثون فعليًا + استخدام هذا الموقع كأداة اختبار

## 1) التحقق الحقيقي عبر الموقع (أسرع طريقة)

1. أنشئ بوتًا: افتح **@BotFather** في تلغرام → `/newbot` → خذ التوكن.
2. افتح `index.html` → الصق التوكن في خانة «توكن البوت».
3. اضغط **✅ تحقق من التوكن**:
   - نجاح ⇒ يظهر اسم البوت و`@username` ومعرّفه الحقيقي (طلب `getMe` فعلي).
   - فشل ⇒ تظهر رسالة تلغرام نفسها (مثل `401 Unauthorized`).
4. اكتب معرّف حسابك الرقمي في «معرّف المالك» ثم **📨 إرسال رسالة** لتصل رسالة حقيقية من البوت.
   - إن ظهرت رسالة `chat not found` أو `bot can't initiate conversation`: افتح البوت في تلغرام واضغط **Start** أولًا.

> للحصول على `chat_id` بسرعة: أرسل أي رسالة لبوت مثل `@userinfobot`، أو استخدم أمر `/id` في بوت الويبهوك المرفق.

## 2) تشغيل البوت فعليًا على جهازك

```bash
# 1. تثبيت المكتبة
pip install pyTelegramBotAPI

# 2. ضبط التوكن كمتغيّر بيئة (لا تكتبه داخل الكود)
#    Linux / macOS
export BOT_TOKEN="123456789:AA..."
#    Windows PowerShell
$env:BOT_TOKEN="123456789:AA..."

# 3. التشغيل
python samples/echo_bot.py
```

بعد ظهور `البوت يعمل الآن...` أرسل `/start` إلى البوت في تلغرام.

### باستخدام aiogram

```bash
pip install aiogram
python samples/aiogram_bot.py
```

## 3) تشغيل نسخة Webhook محليًا

```bash
pip install flask
export BOT_TOKEN="123456789:AA..."
export WEBHOOK_SECRET="any-long-random-string"
export PUBLIC_URL="https://your-tunnel.example.com"   # اختياري لضبط الويبهوك تلقائيًا
python edgeone-deploy/webhook_bot.py
```

- فحص الحالة: `GET http://localhost:8080/`
- استقبال التحديثات: `POST http://localhost:8080/api/telegram-webhook`
- للاختبار المحلي مع تلغرام تحتاج رابطًا عامًا (مثل نفق Cloudflare / ngrok) لأن تلغرام لا يصل إلى `localhost`.

## 4) أين أستضيف البوت فعليًا؟

| الخيار | يدعم Polling دائم؟ | ملاحظة |
|---|---|---|
| VPS (Ubuntu + systemd) | ✅ | الأكثر تحكمًا، شغّل البوت كخدمة |
| Railway / Render / Koyeb / Fly.io | ✅ (عملية طويلة) | سهل النشر من GitHub |
| Docker على أي سحابة | ✅ | استخدم `python:3.12-slim` |
| EdgeOne Pages (Cloud Functions) | ❌ | استخدم Webhook فقط (مجلد `edgeone-deploy`) |
| GitHub Actions / Serverless آخر | ❌ | غير مناسب لبوت دائم |

### مثال systemd على VPS

```ini
# /etc/systemd/system/mybotservice.service
[Unit]
Description=My Telegram Bot
After=network.target

[Service]
Type=simple
User=bot
WorkingDirectory=/opt/mybotservice
Environment="BOT_TOKEN=123456789:AA..."
ExecStart=/usr/bin/python3 /opt/mybotservice/bot.py
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now mybotservice
sudo journalctl -u mybotservice -f     # متابعة السجل
```

## 5) أخطاء شائعة وحلولها

| الخطأ | السبب | الحل |
|---|---|---|
| `401 Unauthorized` | توكن خاطئ/محذوف | `/token` أو `/revoke` في @BotFather |
| `409 Conflict` | نفس التوكن يعمل بمكانين | أوقف النسخة الأخرى أو استخدم `drop_pending_updates` |
| `chat not found` | لم تبدأ محادثة مع البوت | اضغط Start في تلغرام |
| `ModuleNotFoundError: telebot` | المكتبة غير مثبّتة | `pip install pyTelegramBotAPI` |
| `SyntaxError` | نقص `:` أو أقواس | شغّل زر «تنسيق» وراجع تبويب «الفحص» |
| البوت يعمل ثم يتوقف | استثناء غير معالج | أضف `try/except` و`logging` |
| يعمل محليًا ولا يعمل على الاستضافة | الاستضافة Serverless | استخدم Webhook |

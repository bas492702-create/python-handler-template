"""
echo_bot.py — مثال بسيط لبوت تلغرام باستخدام pyTelegramBotAPI
التشغيل:  pip install pyTelegramBotAPI  ثم  python echo_bot.py
"""
import os
import telebot
from datetime import datetime

# ✅ الأفضل: التوكن من متغيّر بيئة وليس مكتوبًا داخل الكود
BOT_TOKEN = os.environ.get("BOT_TOKEN", "")

bot = telebot.TeleBot(BOT_TOKEN)


@bot.message_handler(commands=["start"])
def send_welcome(message):
    name = message.from_user.first_name or "صديقي"
    bot.reply_to(message, "أهلًا بك يا " + name + "! أنا بوت تجريبي يعمل على EdgeOneHost.")


@bot.message_handler(commands=["help"])
def send_help(message):
    bot.reply_to(message, "الأوامر المتاحة: /start للترحيب، /help لهذه القائمة، /time لمعرفة الوقت، أو أرسل أي نص وسأعيده لك.")


@bot.message_handler(commands=["time"])
def send_time(message):
    bot.reply_to(message, "الوقت الآن: " + datetime.now().strftime("%Y-%m-%d %H:%M:%S"))


@bot.message_handler(func=lambda message: True)
def echo_all(message):
    bot.reply_to(message, "وصلتني رسالتك: " + message.text)


if __name__ == "__main__":
    print("البوت يعمل الآن... اضغط Ctrl+C للإيقاف")
    bot.infinity_polling()

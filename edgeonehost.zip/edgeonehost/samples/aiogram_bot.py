"""
aiogram_bot.py — مثال باستخدام aiogram 3.x (غير متزامن)
التشغيل:  pip install aiogram  ثم  python aiogram_bot.py
"""
import asyncio
import logging
import os

from aiogram import Bot, Dispatcher, F
from aiogram.filters import Command, CommandStart
from aiogram.types import Message

logging.basicConfig(level=logging.INFO)

BOT_TOKEN = os.environ.get("BOT_TOKEN", "")
if not BOT_TOKEN:
    raise SystemExit("ضع التوكن في متغيّر البيئة BOT_TOKEN")

bot = Bot(token=BOT_TOKEN)
dp = Dispatcher()


@dp.message(CommandStart())
async def cmd_start(message: Message):
    await message.answer("أهلًا بك في بوت aiogram! اكتب /help لعرض قائمة الأوامر.")


@dp.message(Command("help"))
async def cmd_help(message: Message):
    await message.answer("الأوامر: /start للترحيب، /help للقائمة، /info لمعلومات التشغيل، وأي نص آخر سأعيده لك.")


@dp.message(Command("info"))
async def cmd_info(message: Message):
    await message.answer("الإصدار: aiogram 3.x، لغة Python 3.11، يعمل عبر polling أو webhook.")


@dp.message(F.text)
async def echo(message: Message):
    await message.answer("صدى: " + message.text)


async def main():
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())
